from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field, model_validator

from .contracts import now_iso
from .db import ExternalStatus, InternalStatus

type JsonScalar = str | int | float | bool | None
type JsonValue = JsonScalar | JsonObject | JsonArray
type JsonObject = dict[str, JsonValue]
type JsonArray = list[JsonValue]


class EventType(str, Enum):
    """EventLog 事件类型枚举。"""

    WAITING_ENTER = "WAITING_ENTER"
    WAITING_EXIT = "WAITING_EXIT"
    DECISION_APPLIED = "DECISION_APPLIED"
    CANDIDATE_VALIDATION_FAILED = "CANDIDATE_VALIDATION_FAILED"


class ActorType(str, Enum):
    """EventLog 参与者类型枚举。"""

    SYSTEM = "system"
    HUMAN = "human"
    API = "api"
    WORKFLOW = "workflow"


class EventLog(BaseModel):
    """EventLog 数据模型，用于记录 HITL 关键事件。

    每个 WAITING_* 转换必须记录:
    - 一个 WAITING_ENTER 事件(进入等待状态时)
    - 一个 WAITING_EXIT 事件(离开等待状态时)

    Attributes:
        id: 事件唯一标识。
        task_id: 关联的任务 ID。
        event_type: 事件类型。
        ts: 事件时间戳。
        actor_type: 参与者类型。
        actor_id: 参与者标识(可选)。
        prev_status: 事件发生前的外部状态(可选)。
        new_status: 事件发生后的外部状态(可选)。
        internal_status: 内部状态(可选)。
        pending_action_id: 关联的 PendingAction ID(可选)。
        decision_id: 关联的 Decision ID(可选)。
        data: 可扩展的审计/回放数据载荷。
    """

    id: str
    task_id: str
    event_type: EventType
    ts: str = Field(default_factory=now_iso)
    actor_type: ActorType
    actor_id: str | None = None
    prev_status: ExternalStatus | None = None
    new_status: ExternalStatus | None = None
    internal_status: InternalStatus | None = None
    pending_action_id: str | None = None
    decision_id: str | None = None
    data: JsonObject = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_event_constraints(self) -> EventLog:
        """根据事件类型验证必需字段和约束。"""
        if self.event_type == EventType.WAITING_ENTER:
            self._validate_waiting_enter()
        elif self.event_type == EventType.WAITING_EXIT:
            self._validate_waiting_exit()
        elif self.event_type == EventType.DECISION_APPLIED:
            self._validate_decision_applied()
        elif self.event_type == EventType.CANDIDATE_VALIDATION_FAILED:
            self._validate_candidate_validation_failed()

        return self

    def _validate_waiting_enter(self) -> None:
        """验证 WAITING_ENTER 事件的约束。"""
        if not self.pending_action_id:
            raise ValueError("WAITING_ENTER requires pending_action_id")

        if "waiting_state" not in self.data:
            raise ValueError("WAITING_ENTER requires data.waiting_state")

        if not self.prev_status:
            raise ValueError("WAITING_ENTER requires prev_status")

        if not self.new_status:
            raise ValueError("WAITING_ENTER requires new_status")

        # new_status 必须是 WAITING_* 状态
        if not self.new_status.value.startswith("WAITING_"):
            raise ValueError(
                "WAITING_ENTER requires new_status to be a WAITING_* state, "
                + f"got {self.new_status.value}",
            )

    def _validate_waiting_exit(self) -> None:
        """验证 WAITING_EXIT 事件的约束。"""
        if "waiting_state" not in self.data:
            raise ValueError("WAITING_EXIT requires data.waiting_state")

        if not self.prev_status:
            raise ValueError("WAITING_EXIT requires prev_status")

        if not self.new_status:
            raise ValueError("WAITING_EXIT requires new_status")

        # prev_status 必须是 WAITING_* 状态
        if not self.prev_status.value.startswith("WAITING_"):
            raise ValueError(
                "WAITING_EXIT requires prev_status to be a WAITING_* state, "
                + f"got {self.prev_status.value}",
            )

    def _validate_decision_applied(self) -> None:
        """验证 DECISION_APPLIED 事件的约束。"""
        if not self.decision_id:
            raise ValueError("DECISION_APPLIED requires decision_id")

        if not self.pending_action_id:
            raise ValueError("DECISION_APPLIED requires pending_action_id")

        if "choice" not in self.data:
            raise ValueError("DECISION_APPLIED requires data.choice")

        if not self.prev_status:
            raise ValueError("DECISION_APPLIED requires prev_status")

        if not self.new_status:
            raise ValueError("DECISION_APPLIED requires new_status")

        # prev_status 必须是 WAITING_* 状态
        if not self.prev_status.value.startswith("WAITING_"):
            raise ValueError(
                "DECISION_APPLIED requires prev_status to be a WAITING_* state, "
                + f"got {self.prev_status.value}",
            )

    def _validate_candidate_validation_failed(self) -> None:
        """验证 CANDIDATE_VALIDATION_FAILED 事件的约束。"""
        if "failure_code" not in self.data:
            raise ValueError(
                "CANDIDATE_VALIDATION_FAILED requires data.failure_code"
            )
        if "failures" not in self.data:
            raise ValueError(
                "CANDIDATE_VALIDATION_FAILED requires data.failures"
            )
        failures = self.data.get("failures")
        if not isinstance(failures, list):
            raise ValueError(
                "CANDIDATE_VALIDATION_FAILED requires data.failures to be a list"
            )
