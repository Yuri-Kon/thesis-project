"""
RemoteModelInvocationService - 远程模型调用服务抽象

职责：
- 提供统一的远程模型调用接口（submit/poll/download）
- 默认实现 REST 客户端（POST predict / GET job / GET results）
- 保留 SSH/SDK 扩展点

设计约束：
- submit_job: 提交作业并返回 job_id
- poll_status: 轮询作业状态
- download_results: 下载作业结果到本地目录
- 产物落为 StepResult + artifacts（可被 Executor/Summarizer 消费）
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import Mapping
from enum import Enum
from pathlib import Path
from typing import TypeGuard, cast, override

import httpx

from src.workflow.errors import FailureType, FailureCode, StepRunError

__all__ = [
    "JobStatus",
    "RemoteModelInvocationService",
    "RESTModelInvocationService",
]

type JsonScalar = str | int | float | bool | None
type JsonValue = JsonScalar | JsonObject | JsonArray
type JsonObject = dict[str, JsonValue]
type JsonArray = list[JsonValue]


class JobStatus(str, Enum):
    """远程作业状态枚举"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    UNKNOWN = "unknown"


class RemoteModelInvocationService(ABC):
    """远程模型调用服务抽象基类

    定义统一的接口，供不同的远程服务实现（REST/SSH/SDK）。
    """

    @abstractmethod
    def submit_job(
        self,
        payload: Mapping[str, JsonValue],
        task_id: str,
        step_id: str,
    ) -> str:
        """提交远程作业

        Args:
            payload: 作业输入参数
            task_id: 任务 ID
            step_id: 步骤 ID

        Returns:
            job_id: 远程作业 ID

        Raises:
            StepRunError: 提交失败
        """

    @abstractmethod
    def poll_status(
        self,
        job_id: str,
    ) -> JobStatus:
        """轮询作业状态

        Args:
            job_id: 远程作业 ID

        Returns:
            JobStatus: 作业状态

        Raises:
            StepRunError: 查询失败
        """

    @abstractmethod
    def download_results(
        self,
        job_id: str,
        output_dir: Path,
    ) -> JsonObject:
        """下载作业结果

        Args:
            job_id: 远程作业 ID
            output_dir: 输出目录

        Returns:
            outputs: 输出字典，包含文件路径和解析的指标

        Raises:
            StepRunError: 下载失败
        """


class RESTModelInvocationService(RemoteModelInvocationService):
    """基于 REST API 的远程模型调用服务

    默认端点约定：
    - POST {base_url}/predict - 提交作业
    - GET {base_url}/job/{job_id} - 查询作业状态
    - GET {base_url}/results/{job_id} - 获取作业结果
    """

    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = 30.0,
        poll_interval: float = 5.0,
        max_poll_attempts: int = 60,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        """初始化 REST 客户端

        Args:
            base_url: 远程服务基础 URL
            timeout: 请求超时时间（秒）
            poll_interval: 轮询间隔（秒）
            max_poll_attempts: 最大轮询次数
            headers: 可选的默认请求头（例如 Authorization）
        """
        self.base_url: str = base_url.rstrip("/")
        self.timeout: float = timeout
        self.poll_interval: float = poll_interval
        self.max_poll_attempts: int = max_poll_attempts
        self.default_headers: dict[str, str] | None = dict(headers) if headers else None
        self.client: httpx.Client = httpx.Client(timeout=timeout)

    def __del__(self) -> None:
        """清理 HTTP 客户端"""
        if hasattr(self, "client"):
            self.client.close()

    @override
    def submit_job(
        self,
        payload: Mapping[str, JsonValue],
        task_id: str,
        step_id: str,
    ) -> str:
        """提交远程作业

        POST {base_url}/predict
        Body: {
            "task_id": "...",
            "step_id": "...",
            "inputs": {...}
        }
        Response: {
            "job_id": "..."
        }
        """
        endpoint = f"{self.base_url}/predict"

        request_data: JsonObject = {
            "task_id": task_id,
            "step_id": step_id,
            "inputs": dict(payload),
        }

        try:
            if self.default_headers:
                response = self.client.post(
                    endpoint,
                    json=request_data,
                    headers=self.default_headers,
                )
            else:
                response = self.client.post(endpoint, json=request_data)
            _ = response.raise_for_status()
            data = _response_json_object(
                response,
                invalid_code=FailureCode.REMOTE_SUBMIT_INVALID_RESPONSE.value,
            )

            job_id = data.get("job_id")
            if not isinstance(job_id, str) or not job_id:
                raise StepRunError(
                    failure_type=FailureType.TOOL_ERROR,
                    message="Remote service response missing 'job_id'",
                    code=FailureCode.REMOTE_SUBMIT_INVALID_RESPONSE.value,
                )

            return job_id

        except httpx.HTTPStatusError as exc:
            # 根据 HTTP 状态码选择失败码
            if exc.response.status_code >= 500:
                failure_code = FailureCode.REMOTE_SUBMIT_HTTP_5XX
            else:
                failure_code = FailureCode.REMOTE_SUBMIT_HTTP_4XX
            raise StepRunError(
                failure_type=FailureType.RETRYABLE
                if exc.response.status_code >= 500
                else FailureType.NON_RETRYABLE,
                message=f"Failed to submit job: HTTP {exc.response.status_code}",
                code=failure_code.value,
            ) from exc
        except httpx.TimeoutException as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Timeout during job submission: {exc}",
                code=FailureCode.REMOTE_SUBMIT_TIMEOUT.value,
            ) from exc
        except httpx.RequestError as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Network error during job submission: {exc}",
                code=FailureCode.REMOTE_SUBMIT_NETWORK_ERROR.value,
            ) from exc
        except Exception as exc:
            raise StepRunError(
                failure_type=FailureType.TOOL_ERROR,
                message=f"Unexpected error during job submission: {exc}",
                code=FailureCode.REMOTE_SUBMIT_UNEXPECTED_ERROR.value,
            ) from exc

    @override
    def poll_status(
        self,
        job_id: str,
    ) -> JobStatus:
        """轮询作业状态

        GET {base_url}/job/{job_id}
        Response: {
            "job_id": "...",
            "status": "pending|running|completed|failed"
        }
        """
        endpoint = f"{self.base_url}/job/{job_id}"

        try:
            if self.default_headers:
                response = self.client.get(endpoint, headers=self.default_headers)
            else:
                response = self.client.get(endpoint)
            _ = response.raise_for_status()
            data = _response_json_object(
                response,
                invalid_code=FailureCode.REMOTE_POLL_UNEXPECTED_ERROR.value,
            )

            status_value = data.get("status")
            status_str = status_value.lower() if isinstance(status_value, str) else "unknown"
            try:
                return JobStatus(status_str)
            except ValueError:
                return JobStatus.UNKNOWN

        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return JobStatus.UNKNOWN
            # 根据 HTTP 状态码选择失败码
            if exc.response.status_code >= 500:
                failure_code = FailureCode.REMOTE_POLL_HTTP_5XX
            else:
                failure_code = FailureCode.REMOTE_POLL_HTTP_4XX
            raise StepRunError(
                failure_type=FailureType.RETRYABLE
                if exc.response.status_code >= 500
                else FailureType.NON_RETRYABLE,
                message=f"Failed to poll job status: HTTP {exc.response.status_code}",
                code=failure_code.value,
            ) from exc
        except httpx.TimeoutException as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Timeout during status polling: {exc}",
                code=FailureCode.REMOTE_POLL_TIMEOUT.value,
            ) from exc
        except httpx.RequestError as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Network error during status polling: {exc}",
                code=FailureCode.REMOTE_POLL_NETWORK_ERROR.value,
            ) from exc
        except Exception as exc:
            raise StepRunError(
                failure_type=FailureType.TOOL_ERROR,
                message=f"Unexpected error during status polling: {exc}",
                code=FailureCode.REMOTE_POLL_UNEXPECTED_ERROR.value,
            ) from exc

    @override
    def download_results(
        self,
        job_id: str,
        output_dir: Path,
    ) -> JsonObject:
        """下载作业结果

        GET {base_url}/results/{job_id}
        Response: {
            "job_id": "...",
            "outputs": {...},
            "artifacts": [
                {"name": "...", "url": "...", "type": "..."},
                ...
            ]
        }
        """
        endpoint = f"{self.base_url}/results/{job_id}"

        try:
            if self.default_headers:
                response = self.client.get(endpoint, headers=self.default_headers)
            else:
                response = self.client.get(endpoint)
            _ = response.raise_for_status()
            data = _response_json_object(
                response,
                invalid_code=FailureCode.REMOTE_DOWNLOAD_UNEXPECTED_ERROR.value,
            )

            outputs = _json_object_field(data, "outputs")
            artifacts = _json_object_list_field(data, "artifacts")

            # 确保输出目录存在
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            # 下载产物文件并映射路径
            downloaded_artifacts: JsonArray = []
            artifact_name_to_path: dict[str, str] = {}

            for artifact in artifacts:
                artifact_name = artifact.get("name")
                artifact_url = artifact.get("url")

                if not isinstance(artifact_name, str) or not isinstance(artifact_url, str):
                    continue

                # 下载文件
                artifact_path = output_dir / artifact_name
                artifact_path.parent.mkdir(parents=True, exist_ok=True)
                self._download_file(artifact_url, artifact_path)
                local_path = str(artifact_path.resolve())
                downloaded_artifacts.append(local_path)
                artifact_name_to_path[artifact_name] = local_path

            # 添加产物路径到输出
            if downloaded_artifacts:
                outputs["artifacts"] = downloaded_artifacts

            # 将 outputs 中的相对路径映射为本地绝对路径
            # 例如：outputs["pdb_path"] = "structure.pdb" -> "/path/to/output/structure.pdb"
            for key, value in list(outputs.items()):
                if isinstance(value, str) and value in artifact_name_to_path:
                    outputs[key] = artifact_name_to_path[value]

            return outputs

        except httpx.HTTPStatusError as exc:
            # 根据 HTTP 状态码选择失败码
            if exc.response.status_code >= 500:
                failure_code = FailureCode.REMOTE_DOWNLOAD_HTTP_5XX
            else:
                failure_code = FailureCode.REMOTE_DOWNLOAD_HTTP_4XX
            raise StepRunError(
                failure_type=FailureType.RETRYABLE
                if exc.response.status_code >= 500
                else FailureType.NON_RETRYABLE,
                message=f"Failed to download results: HTTP {exc.response.status_code}",
                code=failure_code.value,
            ) from exc
        except httpx.TimeoutException as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Timeout during result download: {exc}",
                code=FailureCode.REMOTE_DOWNLOAD_TIMEOUT.value,
            ) from exc
        except httpx.RequestError as exc:
            raise StepRunError(
                failure_type=FailureType.RETRYABLE,
                message=f"Network error during result download: {exc}",
                code=FailureCode.REMOTE_DOWNLOAD_NETWORK_ERROR.value,
            ) from exc
        except Exception as exc:
            raise StepRunError(
                failure_type=FailureType.TOOL_ERROR,
                message=f"Unexpected error during result download: {exc}",
                code=FailureCode.REMOTE_DOWNLOAD_UNEXPECTED_ERROR.value,
            ) from exc

    def _download_file(
        self,
        url: str,
        path: Path,
    ) -> None:
        """下载单个文件

        Args:
            url: 文件 URL
            path: 本地保存路径

        Raises:
            httpx.HTTPStatusError: HTTP 错误
            httpx.RequestError: 网络错误
        """
        if self.default_headers:
            stream_context = self.client.stream(
                "GET",
                url,
                headers=self.default_headers,
            )
        else:
            stream_context = self.client.stream("GET", url)
        with stream_context as response:
            _ = response.raise_for_status()
            with open(path, "wb") as f:
                for chunk in response.iter_bytes(chunk_size=8192):
                    _ = f.write(chunk)

    def wait_for_completion(
        self,
        job_id: str,
    ) -> JobStatus:
        """等待作业完成（阻塞式轮询）

        Args:
            job_id: 远程作业 ID

        Returns:
            JobStatus: 最终作业状态

        Raises:
            StepRunError: 轮询超时或失败
        """
        for _ in range(self.max_poll_attempts):
            status = self.poll_status(job_id)

            if status in (JobStatus.COMPLETED, JobStatus.FAILED):
                return status

            if status == JobStatus.UNKNOWN:
                raise StepRunError(
                    failure_type=FailureType.NON_RETRYABLE,
                    message=f"Job {job_id} status is unknown",
                    code=FailureCode.REMOTE_JOB_UNKNOWN.value,
                )

            time.sleep(self.poll_interval)

        # 超时
        raise StepRunError(
            failure_type=FailureType.RETRYABLE,
            message=f"Job {job_id} polling timeout after {self.max_poll_attempts} attempts",
            code=FailureCode.REMOTE_POLL_TIMEOUT.value,
        )


def _response_json_object(response: httpx.Response, *, invalid_code: str) -> JsonObject:
    payload = cast(object, response.json())
    parsed = _as_json_object(payload)
    if parsed is None:
        raise StepRunError(
            failure_type=FailureType.TOOL_ERROR,
            message="Remote service response payload is not a JSON object",
            code=invalid_code,
        )
    return parsed


def _json_object_field(payload: JsonObject, key: str) -> JsonObject:
    value = payload.get(key)
    if isinstance(value, dict):
        return dict(value)
    return {}


def _json_object_list_field(payload: JsonObject, key: str) -> list[JsonObject]:
    value = payload.get(key)
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _as_json_object(value: object) -> JsonObject | None:
    if not isinstance(value, dict):
        return None
    result: JsonObject = {}
    for key, item in cast(Mapping[object, object], value).items():
        if isinstance(key, str) and _is_json_value(item):
            result[key] = item
    return result


def _is_json_value(value: object) -> TypeGuard[JsonValue]:
    if value is None or isinstance(value, str | int | float | bool):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in cast(list[object], value))
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_value(item)
            for key, item in cast(Mapping[object, object], value).items()
        )
    return False
