from __future__ import annotations

import shutil
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from src.models.contracts import PlanStep
from src.workflow.context import WorkflowContext

__all__ = ["BaseToolAdapter"]


class BaseToolAdapter(ABC):
    """ToolAdapter 抽象基类，统一工具调用入口

    支持本地执行（run_local）和远程执行（run_remote）两种模式。
    具体的适配器可以选择实现其中一种或两种执行方式。
    """

    # 对应 ProteinToolKG 中的 tool.id
    tool_id: str
    # 可选适配器别名，用于注册表检索
    adapter_id: str | None = None

    @abstractmethod
    def resolve_inputs(
        self, step: PlanStep, context: WorkflowContext
    ) -> Dict[str, Any]:
        """将 PlanStep.inputs 解析为工具实际输入"""

    @abstractmethod
    def run_local(
        self, inputs: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """本地执行工具并返回 (outputs, metrics)"""

    def run_remote(
        self,
        inputs: Dict[str, Any],
        output_dir: Optional[Path] = None,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """远程执行工具并返回 (outputs, metrics)

        可选方法，适配器可以选择实现远程执行能力。
        默认实现抛出 NotImplementedError。

        Args:
            inputs: 工具输入参数
            output_dir: 可选的输出目录，用于下载远程结果

        Returns:
            (outputs, metrics): 输出字典和指标字典
                outputs 应包含:
                    - 工具特定的输出字段
                    - artifacts: 可选的产物文件列表
                metrics 应包含:
                    - exec_type: "remote"
                    - duration_ms: 执行时间（毫秒）
                    - job_id: 可选的远程作业 ID

        Raises:
            NotImplementedError: 如果适配器不支持远程执行
            StepRunError: 远程执行失败
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support remote execution"
        )

    def describe_capabilities(self) -> Dict[str, Any]:
        """返回适配器能力摘要。"""
        execution_mode = getattr(self, "execution_mode", None)
        if not isinstance(execution_mode, str) or not execution_mode.strip():
            execution_mode = getattr(self, "default_execution_mode", None)
        return {
            "tool_id": getattr(self, "tool_id", ""),
            "adapter_id": getattr(self, "adapter_id", None),
            "execution_mode": execution_mode,
            "provider": getattr(self, "provider", None),
            "endpoint_type": getattr(self, "endpoint_type", None),
        }

    def healthcheck(self) -> Dict[str, Any]:
        """返回适配器可用性检查结果。"""
        binary = getattr(self, "binary", None)
        if isinstance(binary, str) and binary:
            resolved = shutil.which(binary)
            if resolved is None:
                return {
                    "status": "unavailable",
                    "reason": f"binary '{binary}' not installed",
                }
            return {
                "status": "ready",
                "reason": f"binary '{binary}' resolved",
                "binary_path": resolved,
            }
        return {"status": "ready", "reason": "adapter registered"}

    def normalize_error(self, exc: Exception) -> Dict[str, Any]:
        """将工具异常转为统一结构。"""
        return {
            "error_type": exc.__class__.__name__,
            "message": str(exc),
        }

    def estimate_cost(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """估计执行成本。"""
        return {"level": "medium"}

    def estimate_latency(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """估计执行耗时。"""
        return {"level": "medium"}
