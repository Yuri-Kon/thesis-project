"""PendingAction 等待状态工具函数。

该模块用于在进入 WAITING_* 状态前构造并持久化 PendingAction，
并写入快照与事件日志以满足 HITL 约束。
"""
from __future__ import annotations

from typing import Callable, Iterable, Optional
from uuid import uuid4

from src.infra.event_log_factory import make_waiting_enter
from src.models.contracts import (
    ACTION_SCORE_METADATA_KEY,
    CAPABILITY_READINESS_METADATA_KEY,
    DEFAULT_RECOMMENDATION_REASON_METADATA_KEY,
    FINAL_SCORE_METADATA_KEY,
    PendingAction,
    PendingActionCandidate,
    PendingActionStatus,
    PendingActionType,
    RERANK_REASON_METADATA_KEY,
    RUNTIME_ADJUSTMENT_METADATA_KEY,
    RUNTIME_STATE_SUMMARY_METADATA_KEY,
    SHADOW_SCORE_METADATA_KEY,
    STATIC_SCORE_METADATA_KEY,
    TOOL_READINESS_METADATA_KEY,
    WAITING_RUNTIME_SUMMARY_METADATA_KEY,
    now_iso,
)
from src.models.db import ExternalStatus, InternalStatus, TaskRecord, to_external_status
from src.models.event_log import ActorType
from src.storage.log_store import append_event, write_event_log
from src.workflow.context import WorkflowContext
from src.workflow.snapshots import (
    SnapshotWriter,
    build_context_runtime_state_summary,
    build_task_snapshot,
    default_snapshot_writer,
)
from src.workflow.runtime_policy import runtime_policy_trace

EventLogger = Callable[[dict], None]

_WAITING_ACTION_MAP = {
    InternalStatus.WAITING_PLAN_CONFIRM: PendingActionType.PLAN_CONFIRM,
    InternalStatus.WAITING_PATCH: PendingActionType.PATCH_CONFIRM,
    InternalStatus.WAITING_REPLAN: PendingActionType.REPLAN_CONFIRM,
}

_ACTION_NAME_MAP = {
    PendingActionType.PLAN_CONFIRM: "plan",
    PendingActionType.PATCH_CONFIRM: "patch",
    PendingActionType.REPLAN_CONFIRM: "replan",
}


def build_pending_action(
    task_id: str,
    action_type: PendingActionType,
    candidates: Iterable[PendingActionCandidate] | None = None,
    *,
    pending_action_id: Optional[str] = None,
    default_suggestion: Optional[str] = None,
    default_recommendation: Optional[str] = None,
    explanation: str,
    metadata: Optional[dict] = None,
    created_by: str = "system",
) -> PendingAction:
    """构造最小化 PendingAction 实例。

    Args:
        task_id: 任务 ID。
        action_type: 待决策类型。
        candidates: 候选集合（可为空）。
        pending_action_id: 可选的 PendingAction ID（默认自动生成）。
        default_suggestion: 默认建议的候选 ID。
        default_recommendation: CandidateSetOutput v1 默认推荐候选 ID。
        explanation: 解释说明文本。
        metadata: 可选的 WAITING 回放 / 审计元数据。
        created_by: 创建者标识（默认 system）。

    Returns:
        PendingAction 实例。
    """
    return PendingAction(
        pending_action_id=pending_action_id or f"pa_{uuid4().hex[:8]}",
        task_id=task_id,
        action_type=action_type,
        status=PendingActionStatus.PENDING,
        candidates=list(candidates or []),
        default_suggestion=default_suggestion,
        default_recommendation=default_recommendation,
        explanation=explanation,
        created_at=now_iso(),
        decided_at=None,
        created_by=created_by,
        metadata=dict(metadata or {}),
    )


def enter_waiting_state(
    context: WorkflowContext,
    record: TaskRecord | None,
    pending_action: PendingAction,
    to_status: InternalStatus,
    *,
    reason: Optional[str] = None,
    event_logger: EventLogger | None = None,
    snapshot_writer: SnapshotWriter | None = None,
) -> None:
    """在进入 WAITING_* 前写入 PendingAction 与快照。

    NOTE: This helper does not transition task status. Callers must invoke
    transition_task_status explicitly to enter WAITING_*.

    Args:
        context: 工作流上下文。
        record: 可选的任务持久化记录。
        pending_action: 待写入的 PendingAction。
        to_status: 目标 WAITING_* 内部状态。
        reason: 可选的原因说明（仅用于调用方日志语义）。
        event_logger: 可选的事件日志回调。
        snapshot_writer: 可选的快照写入回调。

    Raises:
        ValueError: 当 PendingAction 与目标 WAITING_* 状态不匹配。
    """
    prev_status, new_status = _validate_before_waiting(
        context, pending_action, to_status, record
    )
    _attach_pending_action(context, record, pending_action)
    _emit_pending_action_created(
        context=context,
        pending_action=pending_action,
        event_logger=event_logger,
    )
    selected_candidate = _select_waiting_candidate(pending_action)
    waiting_runtime_summary = _build_waiting_runtime_summary(
        pending_action=pending_action,
        selected_candidate=selected_candidate,
        waiting_reason=reason,
    )
    if waiting_runtime_summary:
        pending_action.metadata.setdefault(
            WAITING_RUNTIME_SUMMARY_METADATA_KEY,
            waiting_runtime_summary,
        )
    _write_waiting_enter_event(
        context=context,
        pending_action=pending_action,
        to_status=to_status,
        prev_status=prev_status,
        new_status=new_status,
        selected_candidate=selected_candidate,
        reason=reason,
    )
    _build_waiting_snapshot(
        context=context,
        new_status=new_status,
        pending_action=pending_action,
        snapshot_writer=snapshot_writer,
    )


def _validate_waiting_transition(
    context: WorkflowContext,
    pending_action: PendingAction,
    to_status: InternalStatus,
    record: TaskRecord | None,
) -> None:
    """校验 WAITING_* 转移的 PendingAction 一致性。

    Args:
        context: 工作流上下文。
        pending_action: 待验证的 PendingAction。
        to_status: 目标 WAITING_* 内部状态。
        record: 可选的任务持久化记录。

    Raises:
        ValueError: 当状态或 pending_action 不一致时抛出。
    """
    expected_action = _WAITING_ACTION_MAP.get(to_status)
    if expected_action is None:
        raise ValueError(f"{to_status.value} is not a WAITING_* status")
    if pending_action.status != PendingActionStatus.PENDING:
        raise ValueError("pending_action must be pending before entering WAITING_*")
    if pending_action.action_type != expected_action:
        raise ValueError(
            f"pending_action.action_type ({pending_action.action_type.value}) "
            f"does not match waiting status {to_status.value}"
        )
    if pending_action.task_id != context.task.task_id:
        raise ValueError("pending_action.task_id does not match task")
    if record is not None and record.status != to_external_status(context.status):
        raise ValueError("record status does not match context status")


def _validate_before_waiting(
    context: WorkflowContext,
    pending_action: PendingAction,
    to_status: InternalStatus,
    record: TaskRecord | None,
) -> tuple[ExternalStatus, ExternalStatus]:
    _validate_waiting_transition(context, pending_action, to_status, record)
    return to_external_status(context.status), _to_external_waiting_status(to_status)


def _attach_pending_action(
    context: WorkflowContext,
    record: TaskRecord | None,
    pending_action: PendingAction,
) -> None:
    context.pending_action = pending_action
    if record is not None:
        record.pending_action = pending_action


def _emit_pending_action_created(
    *,
    context: WorkflowContext,
    pending_action: PendingAction,
    event_logger: EventLogger | None,
) -> None:
    log_handler = event_logger or _default_event_logger
    log_handler(
        {
            "event": "PENDING_ACTION_CREATED",
            "task_id": context.task.task_id,
            "pending_action_id": pending_action.pending_action_id,
            "action_type": pending_action.action_type.value,
            "candidate_ids": [c.candidate_id for c in pending_action.candidates],
            "default_suggestion": pending_action.default_suggestion,
            "default_recommendation": pending_action.default_recommendation,
        }
    )


def _select_waiting_candidate(
    pending_action: PendingAction,
) -> PendingActionCandidate | None:
    default_candidate_id = (
        pending_action.default_recommendation or pending_action.default_suggestion
    )
    if default_candidate_id:
        for candidate in pending_action.candidates:
            if candidate.candidate_id == default_candidate_id:
                return candidate
    if pending_action.candidates:
        return pending_action.candidates[0]
    return None


def _write_waiting_enter_event(
    *,
    context: WorkflowContext,
    pending_action: PendingAction,
    to_status: InternalStatus,
    prev_status: ExternalStatus,
    new_status: ExternalStatus,
    selected_candidate: PendingActionCandidate | None,
    reason: str | None,
) -> None:
    waiting_enter_event = make_waiting_enter(
        task_id=context.task.task_id,
        pending_action_id=pending_action.pending_action_id,
        prev_status=prev_status,
        new_status=new_status,
        waiting_state=to_status.value,
        actor_type=ActorType.SYSTEM,
        internal_status=to_status,
        data=_build_waiting_enter_data(
            context=context,
            pending_action=pending_action,
            new_status=new_status,
            selected_candidate=selected_candidate,
            reason=reason,
        ),
    )
    write_event_log(waiting_enter_event)


def _build_waiting_snapshot(
    *,
    context: WorkflowContext,
    new_status: ExternalStatus,
    pending_action: PendingAction,
    snapshot_writer: SnapshotWriter | None,
) -> None:
    snapshot = build_task_snapshot(
        context,
        state_override=new_status,
        pending_action_id=pending_action.pending_action_id,
        require_runtime_state=True,
    )
    (snapshot_writer or default_snapshot_writer)(snapshot)


def _build_waiting_enter_data(
    *,
    context: WorkflowContext,
    pending_action: PendingAction,
    new_status: ExternalStatus,
    selected_candidate: PendingActionCandidate | None,
    reason: str | None,
) -> dict[str, object]:
    selected_meta = _candidate_metadata(selected_candidate)
    runtime_state_summary = build_context_runtime_state_summary(
        context,
        require_runtime_state=True,
        external_state=new_status,
    )
    runtime_trace = runtime_policy_trace(context.task)
    return {
        "action_type": pending_action.action_type.value,
        "action_name": _ACTION_NAME_MAP[pending_action.action_type],
        "reason": reason or "entering_waiting_state",
        "candidate_count": len(pending_action.candidates),
        "explanation": pending_action.explanation,
        "candidate_id": selected_candidate.candidate_id if selected_candidate else None,
        "tool_id": _candidate_attr_or_meta(selected_candidate, selected_meta, "tool_id"),
        "capability_id": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "capability_id"
        ),
        "io_type": _candidate_attr_or_meta(selected_candidate, selected_meta, "io_type"),
        "adapter_mode": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "adapter_mode"
        ),
        "adapter_id": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "adapter_id"
        ),
        "execution_mode": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "execution_mode"
        ),
        "provider": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "provider"
        ),
        "endpoint_type": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "endpoint_type"
        ),
        "remote_job_id": _candidate_attr_or_meta(
            selected_candidate, selected_meta, "remote_job_id"
        ),
        "waiting_runtime_summary": pending_action.metadata.get(
            WAITING_RUNTIME_SUMMARY_METADATA_KEY
        )
        if isinstance(pending_action.metadata, dict)
        else None,
        "action_score": _dict_meta(selected_meta, ACTION_SCORE_METADATA_KEY),
        "shadow_score": _dict_meta(selected_meta, SHADOW_SCORE_METADATA_KEY),
        "terminal_policy": selected_meta.get("terminal_policy"),
        "terminal_reason": selected_meta.get("terminal_reason"),
        "replan_mode": selected_meta.get("replan_mode"),
        "preserve_prefix_until_step_index": selected_meta.get(
            "preserve_prefix_until_step_index"
        ),
        "evidence_source": _dict_meta(
            selected_meta, DEFAULT_RECOMMENDATION_REASON_METADATA_KEY
        ),
        "tool_readiness": _dict_meta(selected_meta, TOOL_READINESS_METADATA_KEY),
        "capability_readiness": _dict_meta(
            selected_meta, CAPABILITY_READINESS_METADATA_KEY
        ),
        "runtime_policy": runtime_trace["runtime_policy"],
        "belief_state_enabled": runtime_trace["belief_state_enabled"],
        "runtime_state_summary": runtime_state_summary,
    }


def _candidate_metadata(
    candidate: PendingActionCandidate | None,
) -> dict[str, object]:
    if candidate is not None and isinstance(candidate.metadata, dict):
        return dict(candidate.metadata)
    return {}


def _candidate_attr_or_meta(
    candidate: PendingActionCandidate | None,
    metadata: dict[str, object],
    field_name: str,
) -> object:
    if candidate is not None:
        value = getattr(candidate, field_name, None)
        if value is not None:
            return value
    return metadata.get(field_name)


def _dict_meta(metadata: dict[str, object], key: str) -> object:
    value = metadata.get(key)
    return value if isinstance(value, dict) else None


def _to_external_waiting_status(to_status: InternalStatus) -> ExternalStatus:
    """将 WAITING_* 内部状态映射为对外状态。

    Args:
        to_status: 内部状态。

    Returns:
        ExternalStatus 对外状态。
    """
    if to_status in _WAITING_ACTION_MAP:
        return to_external_status(to_status)
    return to_external_status(to_status)


def _default_event_logger(event: dict) -> None:
    """默认事件日志记录器（写入 log_store）。

    Args:
        event: 事件字典。
    """
    task_id = event.get("task_id")
    if not task_id:
        return
    append_event(task_id, event)


def _build_waiting_runtime_summary(
    *,
    pending_action: PendingAction,
    selected_candidate: PendingActionCandidate | None,
    waiting_reason: str | None,
) -> dict | None:
    candidate_metadata = (
        selected_candidate.metadata
        if selected_candidate is not None and isinstance(selected_candidate.metadata, dict)
        else {}
    )
    summary: dict[str, object] = {}
    if selected_candidate is not None:
        summary["selected_candidate_id"] = selected_candidate.candidate_id
    if pending_action.default_recommendation:
        summary["default_recommendation"] = pending_action.default_recommendation
    if waiting_reason:
        summary["waiting_reason"] = waiting_reason

    for key in (
        RUNTIME_STATE_SUMMARY_METADATA_KEY,
        DEFAULT_RECOMMENDATION_REASON_METADATA_KEY,
        STATIC_SCORE_METADATA_KEY,
        RUNTIME_ADJUSTMENT_METADATA_KEY,
        FINAL_SCORE_METADATA_KEY,
        RERANK_REASON_METADATA_KEY,
        ACTION_SCORE_METADATA_KEY,
        SHADOW_SCORE_METADATA_KEY,
        "terminal_policy",
        "terminal_reason",
        "replan_mode",
        "preserve_prefix_until_step_index",
        "adapter_id",
        "execution_mode",
        "provider",
        "endpoint_type",
        "remote_job_id",
        "failure_code",
        "recovery_hint",
    ):
        value = candidate_metadata.get(key)
        if value is not None:
            summary[key] = value

    return summary or None
