from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from src.infra.event_log_factory import make_waiting_exit, make_decision_applied
from src.models.contracts import (
    DECISION_SUMMARY_ARTIFACT_KEY,
    Decision,
    DecisionChoice,
    PendingAction,
    PendingActionCandidate,
    PendingActionStatus,
    PendingActionType,
    Plan,
    PlanPatch,
    now_iso,
)
from src.models.validation import (
    DecisionValidationError,
    find_pending_action_candidate,
    validate_decision_for_pending_action,
)
from src.models.db import ExternalStatus, InternalStatus, TaskRecord, to_external_status
from src.models.event_log import ActorType
from src.storage.log_store import append_event, write_event_log
from src.workflow.context import WorkflowContext
from src.workflow.patch import apply_patch
from src.workflow.pending_action import build_pending_action, enter_waiting_state
from src.workflow.recovery import (
    extract_candidate_recovery_metadata,
    is_terminal_stop_candidate,
)
from src.workflow.snapshots import (
    SnapshotWriter,
    build_context_runtime_state_summary,
    build_task_snapshot,
    default_snapshot_writer,
    extract_pending_action_waiting_summary,
)
from src.workflow.status import StatusLogger, transition_task_status
from src.workflow.runtime_policy import runtime_policy_trace

EventLogger = Callable[[dict], None]

_EXPECTED_EXTERNAL = {
    PendingActionType.PLAN_CONFIRM: ExternalStatus.WAITING_PLAN_CONFIRM,
    PendingActionType.PATCH_CONFIRM: ExternalStatus.WAITING_PATCH_CONFIRM,
    PendingActionType.REPLAN_CONFIRM: ExternalStatus.WAITING_REPLAN_CONFIRM,
}

_ACTION_NAME_MAP = {
    PendingActionType.PLAN_CONFIRM: "plan",
    PendingActionType.PATCH_CONFIRM: "patch",
    PendingActionType.REPLAN_CONFIRM: "replan",
}


class DecisionApplyError(ValueError):
    """Base error for decision application."""


class DecisionConflictError(DecisionApplyError):
    """409-like conflict: pending action already resolved or status mismatch."""

    status_code = 409


@dataclass(frozen=True)
class DecisionApplyResult:
    status: ExternalStatus
    internal_status: InternalStatus
    plan: Optional[Plan] = None
    plan_patch: Optional[PlanPatch] = None
    pending_action: Optional[PendingAction] = None


def apply_plan_confirm_decision(
    context: WorkflowContext,
    record: TaskRecord | None,
    decision: Decision,
    *,
    pending_action: PendingAction | None = None,
    event_logger: EventLogger | None = None,
    status_logger: StatusLogger | None = None,
    snapshot_writer: SnapshotWriter | None = None,
) -> DecisionApplyResult:
    """Apply a plan_confirm decision."""
    action = _resolve_pending_action(context, record, pending_action)
    _ensure_action_type(action, PendingActionType.PLAN_CONFIRM)
    _validate_decision_and_state(context, record, action, decision)

    # Record the WAITING_* status before transition
    prev_status = to_external_status(context.status)

    logger = event_logger or _default_event_logger
    logger(_decision_event("DECISION_SUBMITTED", context, action, decision))

    selected_plan: Optional[Plan] = None
    if decision.choice == DecisionChoice.ACCEPT:
        candidate = _select_candidate(action, decision)
        selected_plan = _ensure_plan_payload(candidate)
        _apply_plan_to_context(context, record, selected_plan)
        transition_task_status(
            context,
            record,
            InternalStatus.PLANNED,
            reason="decision_accept_plan",
            logger=status_logger,
        )
        action.status = PendingActionStatus.DECIDED
    elif decision.choice == DecisionChoice.REPLAN:
        transition_task_status(
            context,
            record,
            InternalStatus.PLANNING,
            reason="decision_replan_requested",
            logger=status_logger,
        )
        action.status = PendingActionStatus.DECIDED
    elif decision.choice == DecisionChoice.CANCEL:
        transition_task_status(
            context,
            record,
            InternalStatus.CANCELLED,
            reason="decision_cancelled",
            logger=status_logger,
        )
        action.status = PendingActionStatus.CANCELLED
    else:
        raise DecisionApplyError(f"Unsupported decision choice: {decision.choice}")

    action.decided_at = now_iso()
    _sync_pending_action(context, record, action)

    # 持久化 Decision 到 TaskRecord
    if record is not None:
        record.decisions.append(decision)

    # Emit structured EventLog events
    _emit_decision_applied_event(context, action, decision, prev_status)
    _emit_waiting_exit_event(
        context,
        action,
        decision,
        prev_status,
        waiting_state=InternalStatus.WAITING_PLAN_CONFIRM.value,
    )

    logger(_decision_event("DECISION_APPLIED", context, action, decision))
    _write_snapshot(context, action, snapshot_writer, decision=decision)

    return DecisionApplyResult(
        status=to_external_status(context.status),
        internal_status=context.status,
        plan=selected_plan,
        pending_action=action,
    )


def apply_patch_confirm_decision(
    context: WorkflowContext,
    record: TaskRecord | None,
    decision: Decision,
    *,
    pending_action: PendingAction | None = None,
    event_logger: EventLogger | None = None,
    status_logger: StatusLogger | None = None,
    snapshot_writer: SnapshotWriter | None = None,
) -> DecisionApplyResult:
    """Apply a patch_confirm decision."""
    action = _resolve_pending_action(context, record, pending_action)
    _ensure_action_type(action, PendingActionType.PATCH_CONFIRM)
    _validate_decision_and_state(context, record, action, decision)

    # Record the WAITING_* status before transition
    prev_status = to_external_status(context.status)

    logger = event_logger or _default_event_logger
    logger(_decision_event("DECISION_SUBMITTED", context, action, decision))

    selected_patch: Optional[PlanPatch] = None
    selected_plan: Optional[Plan] = None
    if decision.choice == DecisionChoice.ACCEPT:
        candidate = _select_candidate(action, decision)
        selected_patch = _ensure_patch_payload(candidate)
        selected_plan = _apply_patch_to_context(context, record, selected_patch)
        if context.status == InternalStatus.WAITING_PATCH:
            transition_task_status(
                context,
                record,
                InternalStatus.PATCHING,
                reason="decision_accept_patch",
                logger=status_logger,
            )
        transition_task_status(
            context,
            record,
            InternalStatus.RUNNING,
            reason="decision_patch_applied",
            logger=status_logger,
        )
        action.status = PendingActionStatus.DECIDED
    elif decision.choice == DecisionChoice.REPLAN:
        action.status = PendingActionStatus.CANCELLED
        action.decided_at = now_iso()
        _sync_pending_action(context, record, action)

        # 持久化 Decision 到 TaskRecord
        if record is not None:
            record.decisions.append(decision)

        # Emit WAITING_EXIT for the cancelled patch confirm
        _emit_waiting_exit_event(
            context,
            action,
            decision,
            prev_status,
            waiting_state=InternalStatus.WAITING_PATCH.value,
        )

        replan_action_id = f"{action.pending_action_id}_replan"
        replan_action = build_pending_action(
            task_id=context.task.task_id,
            action_type=PendingActionType.REPLAN_CONFIRM,
            candidates=[],
            pending_action_id=replan_action_id,
            default_suggestion=None,
            explanation="patch_confirm rejected; replan confirmation required",
        )
        enter_waiting_state(
            context,
            record,
            replan_action,
            InternalStatus.WAITING_REPLAN,
            event_logger=event_logger,
            snapshot_writer=snapshot_writer,
        )
        transition_task_status(
            context,
            record,
            InternalStatus.WAITING_REPLAN,
            reason="decision_replan_requested",
            logger=status_logger,
        )

        logger(_decision_event("DECISION_APPLIED", context, action, decision))
        _write_snapshot(context, replan_action, snapshot_writer, decision=decision)
        return DecisionApplyResult(
            status=to_external_status(context.status),
            internal_status=context.status,
            plan=None,
            plan_patch=None,
            pending_action=replan_action,
        )
    elif decision.choice == DecisionChoice.CANCEL:
        transition_task_status(
            context,
            record,
            InternalStatus.CANCELLED,
            reason="decision_cancelled",
            logger=status_logger,
        )
        action.status = PendingActionStatus.CANCELLED
    else:
        raise DecisionApplyError(f"Unsupported decision choice: {decision.choice}")

    action.decided_at = now_iso()
    _sync_pending_action(context, record, action)

    # 持久化 Decision 到 TaskRecord
    if record is not None:
        record.decisions.append(decision)

    # Emit structured EventLog events
    _emit_decision_applied_event(context, action, decision, prev_status)
    _emit_waiting_exit_event(
        context,
        action,
        decision,
        prev_status,
        waiting_state=InternalStatus.WAITING_PATCH.value,
    )

    logger(_decision_event("DECISION_APPLIED", context, action, decision))
    _write_snapshot(context, action, snapshot_writer, decision=decision)

    return DecisionApplyResult(
        status=to_external_status(context.status),
        internal_status=context.status,
        plan=selected_plan,
        plan_patch=selected_patch,
        pending_action=action,
    )


def apply_replan_confirm_decision(
    context: WorkflowContext,
    record: TaskRecord | None,
    decision: Decision,
    *,
    pending_action: PendingAction | None = None,
    event_logger: EventLogger | None = None,
    status_logger: StatusLogger | None = None,
    snapshot_writer: SnapshotWriter | None = None,
) -> DecisionApplyResult:
    """Apply a replan_confirm decision."""
    action = _resolve_pending_action(context, record, pending_action)
    _ensure_action_type(action, PendingActionType.REPLAN_CONFIRM)
    _validate_decision_and_state(context, record, action, decision)

    # Record the WAITING_* status before transition
    prev_status = to_external_status(context.status)

    logger = event_logger or _default_event_logger
    logger(_decision_event("DECISION_SUBMITTED", context, action, decision))

    selected_plan: Optional[Plan] = None
    if decision.choice == DecisionChoice.ACCEPT:
        candidate = _select_candidate(action, decision)
        if is_terminal_stop_candidate(candidate):
            candidate_meta = extract_candidate_recovery_metadata(candidate)
            transition_task_status(
                context,
                record,
                InternalStatus.FAILED,
                reason=str(
                    candidate_meta.get("terminal_reason")
                    or "decision_accept_terminal_stop"
                ),
                logger=status_logger,
            )
        else:
            selected_plan = _ensure_plan_payload(candidate)
            _apply_plan_to_context(context, record, selected_plan)
            transition_task_status(
                context,
                record,
                InternalStatus.PLANNING,
                reason="decision_accept_replan",
                logger=status_logger,
            )
        action.status = PendingActionStatus.DECIDED
    elif decision.choice == DecisionChoice.CONTINUE:
        transition_task_status(
            context,
            record,
            InternalStatus.RUNNING,
            reason="decision_continue_running",
            logger=status_logger,
        )
        action.status = PendingActionStatus.DECIDED
    elif decision.choice == DecisionChoice.CANCEL:
        transition_task_status(
            context,
            record,
            InternalStatus.CANCELLED,
            reason="decision_cancelled",
            logger=status_logger,
        )
        action.status = PendingActionStatus.CANCELLED
    else:
        raise DecisionApplyError(f"Unsupported decision choice: {decision.choice}")

    action.decided_at = now_iso()
    _sync_pending_action(context, record, action)

    # 持久化 Decision 到 TaskRecord
    if record is not None:
        record.decisions.append(decision)

    # Emit structured EventLog events
    _emit_decision_applied_event(context, action, decision, prev_status)
    _emit_waiting_exit_event(
        context,
        action,
        decision,
        prev_status,
        waiting_state=InternalStatus.WAITING_REPLAN.value,
    )

    logger(_decision_event("DECISION_APPLIED", context, action, decision))
    _write_snapshot(context, action, snapshot_writer, decision=decision)

    return DecisionApplyResult(
        status=to_external_status(context.status),
        internal_status=context.status,
        plan=selected_plan,
        pending_action=action,
    )


def _resolve_pending_action(
    context: WorkflowContext,
    record: TaskRecord | None,
    pending_action: PendingAction | None,
) -> PendingAction:
    action = (
        pending_action
        or context.pending_action
        or (record.pending_action if record is not None else None)
    )
    if action is None:
        raise DecisionApplyError("PendingAction is required for decision application")
    if (
        context.pending_action
        and context.pending_action.pending_action_id != action.pending_action_id
    ):
        raise DecisionApplyError(
            "Context pending_action does not match provided action"
        )
    if (
        record is not None
        and record.pending_action
        and (record.pending_action.pending_action_id != action.pending_action_id)
    ):
        raise DecisionApplyError("Record pending_action does not match provided action")
    return action


def _ensure_action_type(
    action: PendingAction,
    expected: PendingActionType,
) -> None:
    if action.action_type != expected:
        raise DecisionApplyError(
            f"PendingAction.action_type ({action.action_type.value}) "
            f"does not match expected {expected.value}"
        )


def _validate_decision_and_state(
    context: WorkflowContext,
    record: TaskRecord | None,
    action: PendingAction,
    decision: Decision,
) -> None:
    if action.status != PendingActionStatus.PENDING:
        raise DecisionConflictError("PendingAction has already been decided")
    if decision.task_id != context.task.task_id:
        raise DecisionApplyError("Decision.task_id does not match task")
    if decision.pending_action_id != action.pending_action_id:
        raise DecisionApplyError("Decision.pending_action_id does not match action")
    expected_status = _EXPECTED_EXTERNAL[action.action_type]
    actual_status = to_external_status(context.status)
    if actual_status != expected_status:
        raise DecisionConflictError(
            f"Task status {actual_status.value} does not match "
            f"PendingAction {action.action_type.value}"
        )
    if record is not None and record.status != expected_status:
        raise DecisionConflictError(
            f"Record status {record.status.value} does not match "
            f"PendingAction {action.action_type.value}"
        )
    try:
        validate_decision_for_pending_action(action, decision)
    except DecisionValidationError as exc:
        raise DecisionApplyError(str(exc)) from exc


def _select_candidate(
    action: PendingAction,
    decision: Decision,
) -> PendingActionCandidate:
    selected_id = decision.selected_candidate_id
    if not selected_id:
        raise DecisionApplyError("selected_candidate_id is required for accept")
    candidate = find_pending_action_candidate(action, selected_id)
    if candidate is None:
        raise DecisionApplyError("selected_candidate_id is not in candidates")
    return candidate


def _ensure_plan_payload(candidate: PendingActionCandidate) -> Plan:
    payload = candidate.payload
    if not isinstance(payload, Plan):
        raise DecisionApplyError("Selected candidate payload is not a Plan")
    return payload


def _ensure_patch_payload(candidate: PendingActionCandidate) -> PlanPatch:
    payload = candidate.payload
    if not isinstance(payload, PlanPatch):
        raise DecisionApplyError("Selected candidate payload is not a PlanPatch")
    return payload


def _apply_plan_to_context(
    context: WorkflowContext,
    record: TaskRecord | None,
    plan: Plan,
) -> None:
    context.plan = plan
    if record is not None:
        record.plan = plan


def _apply_patch_to_context(
    context: WorkflowContext,
    record: TaskRecord | None,
    patch: PlanPatch,
) -> Plan:
    if context.plan is None:
        raise DecisionApplyError("Cannot apply patch without an existing plan")
    patched_plan = apply_patch(context.plan, patch)
    context.plan = patched_plan
    if record is not None:
        record.plan = patched_plan
    return patched_plan


def _sync_pending_action(
    context: WorkflowContext,
    record: TaskRecord | None,
    action: PendingAction,
) -> None:
    context.pending_action = action
    if record is not None:
        record.pending_action = action


def _write_snapshot(
    context: WorkflowContext,
    action: PendingAction,
    snapshot_writer: SnapshotWriter | None,
    *,
    decision: Decision | None = None,
) -> None:
    pending_id = None
    if (
        to_external_status(context.status)
        in (
            ExternalStatus.WAITING_PLAN_CONFIRM,
            ExternalStatus.WAITING_PATCH_CONFIRM,
            ExternalStatus.WAITING_REPLAN_CONFIRM,
        )
        and action.status == PendingActionStatus.PENDING
    ):
        pending_id = action.pending_action_id
    snapshot = build_task_snapshot(
        context,
        pending_action_id=pending_id,
        artifacts=_build_decision_artifacts(context, action, decision),
        require_runtime_state=True,
    )
    (snapshot_writer or default_snapshot_writer)(snapshot)


def _decision_event(
    event_name: str,
    context: WorkflowContext,
    action: PendingAction,
    decision: Decision,
) -> dict:
    return {
        "event": event_name,
        "task_id": context.task.task_id,
        "pending_action_id": action.pending_action_id,
        "decision_id": decision.decision_id,
        "choice": decision.choice.value,
        "selected_candidate_id": decision.selected_candidate_id,
        "state": to_external_status(context.status).value,
        "internal_status": context.status.value,
    }


def _default_event_logger(event: dict) -> None:
    task_id = event.get("task_id")
    if not task_id:
        return
    append_event(task_id, event)


def _emit_decision_applied_event(
    context: WorkflowContext,
    action: PendingAction,
    decision: Decision,
    prev_status: ExternalStatus,
) -> None:
    """Emit DECISION_APPLIED EventLog.

    Args:
        context: Workflow context.
        action: The resolved PendingAction.
        decision: The decision being applied.
        prev_status: Previous external status (must be WAITING_*).
    """
    current_status = to_external_status(context.status)
    selected_candidate = None
    if decision.selected_candidate_id:
        selected_candidate = find_pending_action_candidate(
            action,
            decision.selected_candidate_id,
        )
    candidate_meta = (
        extract_candidate_recovery_metadata(selected_candidate)
        if selected_candidate is not None
        else {}
    )
    runtime_trace = runtime_policy_trace(context.task)
    decision_event = make_decision_applied(
        task_id=context.task.task_id,
        decision_id=decision.decision_id,
        pending_action_id=action.pending_action_id,
        prev_status=prev_status,
        new_status=current_status,
        choice=decision.choice.value,
        actor_type=ActorType.HUMAN,
        internal_status=context.status,
        data={
            "selected_candidate_id": decision.selected_candidate_id,
            "action_type": action.action_type.value,
            "action_name": _ACTION_NAME_MAP[action.action_type],
            "decided_by": decision.decided_by,
            "decision_source": "human",
            "comment": decision.comment,
            "tool_id": (
                selected_candidate.tool_id if selected_candidate else candidate_meta.get("tool_id")
            ),
            "capability_id": (
                selected_candidate.capability_id
                if selected_candidate
                else candidate_meta.get("capability_id")
            ),
            "io_type": (
                selected_candidate.io_type if selected_candidate else candidate_meta.get("io_type")
            ),
            "adapter_mode": (
                selected_candidate.adapter_mode
                if selected_candidate
                else candidate_meta.get("adapter_mode")
            ),
            "adapter_id": (
                selected_candidate.adapter_id
                if selected_candidate
                else candidate_meta.get("adapter_id")
            ),
            "execution_mode": (
                selected_candidate.execution_mode
                if selected_candidate
                else candidate_meta.get("execution_mode")
            ),
            "provider": (
                selected_candidate.provider
                if selected_candidate
                else candidate_meta.get("provider")
            ),
            "endpoint_type": (
                selected_candidate.endpoint_type
                if selected_candidate
                else candidate_meta.get("endpoint_type")
            ),
            "remote_job_id": (
                selected_candidate.remote_job_id
                if selected_candidate
                else candidate_meta.get("remote_job_id")
            ),
            "waiting_runtime_summary": extract_pending_action_waiting_summary(context),
            "action_score": candidate_meta.get("action_score"),
            "shadow_score": candidate_meta.get("shadow_score"),
            "evidence_source": candidate_meta.get("default_recommendation_reason"),
            "execution_mode": candidate_meta.get("execution_mode"),
            "provider": candidate_meta.get("provider"),
            "endpoint_type": candidate_meta.get("endpoint_type"),
            "remote_job_id": candidate_meta.get("remote_job_id"),
            "terminal_policy": candidate_meta.get("terminal_policy"),
            "terminal_reason": candidate_meta.get("terminal_reason"),
            "runtime_policy": runtime_trace["runtime_policy"],
            "belief_state_enabled": runtime_trace["belief_state_enabled"],
            "runtime_state_summary": build_context_runtime_state_summary(
                context,
                require_runtime_state=True,
            ),
        },
    )
    write_event_log(decision_event)


def _emit_waiting_exit_event(
    context: WorkflowContext,
    action: PendingAction,
    decision: Decision,
    prev_status: ExternalStatus,
    waiting_state: str,
) -> None:
    """Emit WAITING_EXIT EventLog.

    Args:
        context: Workflow context.
        action: The resolved PendingAction.
        prev_status: Previous external status (must be WAITING_*).
        waiting_state: The waiting state description.
    """
    current_status = to_external_status(context.status)
    selected_candidate = None
    if decision.selected_candidate_id:
        selected_candidate = find_pending_action_candidate(
            action,
            decision.selected_candidate_id,
        )
    candidate_meta = (
        extract_candidate_recovery_metadata(selected_candidate)
        if selected_candidate is not None
        else {}
    )
    runtime_trace = runtime_policy_trace(context.task)
    exit_event = make_waiting_exit(
        task_id=context.task.task_id,
        prev_status=prev_status,
        new_status=current_status,
        waiting_state=waiting_state,
        actor_type=ActorType.HUMAN,
        internal_status=context.status,
        pending_action_id=action.pending_action_id,
        data={
            "action_type": action.action_type.value,
            "action_name": _ACTION_NAME_MAP[action.action_type],
            "action_status": action.status.value,
            "decided_by": decision.decided_by,
            "decision_source": "human",
            "waiting_runtime_summary": extract_pending_action_waiting_summary(context),
            "action_score": candidate_meta.get("action_score"),
            "shadow_score": candidate_meta.get("shadow_score"),
            "evidence_source": candidate_meta.get("default_recommendation_reason"),
            "terminal_policy": candidate_meta.get("terminal_policy"),
            "terminal_reason": candidate_meta.get("terminal_reason"),
            "runtime_policy": runtime_trace["runtime_policy"],
            "belief_state_enabled": runtime_trace["belief_state_enabled"],
            "runtime_state_summary": build_context_runtime_state_summary(
                context,
                require_runtime_state=True,
            ),
        },
    )
    write_event_log(exit_event)


def _build_decision_artifacts(
    context: WorkflowContext,
    action: PendingAction,
    decision: Decision | None,
) -> dict[str, object] | None:
    if decision is None:
        return None
    selected_candidate = None
    if decision.selected_candidate_id:
        selected_candidate = find_pending_action_candidate(
            action,
            decision.selected_candidate_id,
        )
    candidate_meta = (
        extract_candidate_recovery_metadata(selected_candidate)
        if selected_candidate is not None
        else {}
    )
    summary = {
        "decision_id": decision.decision_id,
        "pending_action_id": action.pending_action_id,
        "choice": decision.choice.value,
        "selected_candidate_id": decision.selected_candidate_id,
        "action_type": action.action_type.value,
        "action_status": action.status.value,
        "decided_by": decision.decided_by,
        "decision_source": "human",
        "terminal_policy": candidate_meta.get("terminal_policy"),
        "terminal_reason": candidate_meta.get("terminal_reason"),
        "runtime_state_summary": build_context_runtime_state_summary(
            context,
            require_runtime_state=True,
        ),
        "waiting_runtime_summary": extract_pending_action_waiting_summary(context),
    }
    return {DECISION_SUMMARY_ARTIFACT_KEY: summary}
