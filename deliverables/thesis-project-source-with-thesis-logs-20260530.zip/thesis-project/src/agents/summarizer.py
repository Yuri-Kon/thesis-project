from __future__ import annotations
from pathlib import Path
import json
from typing import Any, Dict, List, Optional, cast

from pydantic import BaseModel, Field

from src.agents.summarizer_sections import DeNovoReportView, render_de_novo_markdown
from src.models.contracts import DesignResult, now_iso, ProteinDesignTask, StepResult
from src.workflow.context import WorkflowContext


# ============================================================================
# De Novo 设计报告数据模型
# ============================================================================


class StepSummary(BaseModel):
    """单个步骤的执行摘要"""

    step_id: str
    tool: str
    status: str  # "success" | "failed" | "skipped"
    inputs_summary: Dict[str, Any] = Field(default_factory=dict)
    outputs_summary: Dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None


class ToolChainInfo(BaseModel):
    """工具链信息"""

    sequence_design_tool: Optional[str] = None
    structure_prediction_tool: Optional[str] = None
    description: str = ""


class SuccessReport(BaseModel):
    """成功场景报告内容"""

    final_sequence: Optional[str] = None
    sequence_length: Optional[int] = None
    structure_pdb_path: Optional[str] = None
    plddt_mean: Optional[float] = None
    confidence: Optional[str] = None
    objective_score: Optional[float] = None
    objective_top_k: List[Dict[str, Any]] = Field(default_factory=list)
    component_scores: Dict[str, Any] = Field(default_factory=dict)
    objective_warnings: List[str] = Field(default_factory=list)
    evidence_refs: List[Dict[str, Any]] = Field(default_factory=list)
    posterior_score: Dict[str, Any] = Field(default_factory=dict)
    rank_reason: Optional[str] = None
    structure_similarity: Dict[str, Any] = Field(default_factory=dict)


class FailureReport(BaseModel):
    """失败场景报告内容"""

    failed_step_id: Optional[str] = None
    failed_tool: Optional[str] = None
    failure_type: Optional[str] = None
    error_message: Optional[str] = None
    safety_action: Optional[str] = None  # "allow" | "warn" | "block"
    safety_reason: Optional[str] = None
    suggested_next_steps: List[str] = Field(default_factory=list)


class DeNovoReport(BaseModel):
    """De Novo 蛋白设计任务报告"""

    task_id: str
    task_description: str
    design_goal: str
    created_at: str
    status: str  # "success" | "failed" | "partial"

    tool_chain: ToolChainInfo
    step_summaries: List[StepSummary] = Field(default_factory=list)

    # 成功或失败的详细信息（二选一）
    success_report: Optional[SuccessReport] = None
    failure_report: Optional[FailureReport] = None

    # 原始数据引用
    report_json_path: Optional[str] = None
    report_markdown_path: Optional[str] = None


class SummarizerAgent:
    """最小可用 SummarizerAgent: 根据已完成的步骤，生成一个简单的 DesignResult

    当前实现：简单汇总步骤结果，生成 JSON 报告
    后续将支持更丰富的报告格式（Markdown、HTML等）
    """

    def summarize(self, context: WorkflowContext) -> DesignResult:
        """汇总工作流结果，生成最终设计结果

        Args:
            context: 工作流上下文

        Returns:
            DesignResult: 最终设计结果
        """
        task_id = context.task.task_id

        # 简单策略：从 step_results 中提取信息
        seq_len = None
        final_sequence = None
        structure_pdb_path = None
        structure_scores = {}  # 与结构相关的评分指标
        execution_steps: list[dict] = []

        if context.plan is not None:
            ordered_step_ids = [step.id for step in context.plan.steps]
        else:
            ordered_step_ids = list(context.step_results.keys())

        for step_id in ordered_step_ids:
            r = context.step_results.get(step_id)
            if r is None:
                continue
            # 提取序列长度
            if "sequence_length" in r.outputs:
                seq_len = r.outputs["sequence_length"]
            if "sequence" in r.outputs:
                final_sequence = r.outputs["sequence"]

            # 提取结构预测结果（通用方式，不限于特定工具）
            # 只要 outputs 包含 pdb_path，就认为是结构预测工具的输出
            if "pdb_path" in r.outputs:
                # 更新 PDB 路径
                structure_pdb_path = r.outputs["pdb_path"]

                # 重要：清空旧的结构评分，确保指标与当前 PDB 路径一致
                # 这样避免了将新结构与旧指标错误配对的问题
                structure_scores = {}

                # 提取该步骤的结构预测指标
                if "metrics" in r.outputs:
                    metrics = r.outputs["metrics"]
                    # 提取 pLDDT（结构预测置信度的标准指标）
                    if "plddt_mean" in metrics:
                        structure_scores["plddt_mean"] = metrics["plddt_mean"]
                    # 提取置信度等级（如果有）
                    if "confidence" in metrics:
                        structure_scores["confidence"] = metrics["confidence"]

            execution_steps.append(
                {
                    "step_id": r.step_id,
                    "tool": r.tool,
                    "exec_type": r.metrics.get("exec_type"),
                    "provider": r.metrics.get("provider"),
                    "model_id": r.metrics.get("model_id"),
                    "backend": r.metrics.get("backend"),
                }
            )

        scores = {}
        if seq_len is None and final_sequence is not None:
            seq_len = len(final_sequence)
        if seq_len is not None:
            scores["sequence_length"] = seq_len
        # 合并结构预测的分数
        scores.update(structure_scores)
        objective_scoring = _extract_objective_scoring_summary(context)
        structure_similarity = _extract_structure_similarity_summary(context)
        objective_score = objective_scoring.get("objective_score")
        if isinstance(objective_score, (int, float)):
            scores["objective_score"] = objective_score
        objective_gap = objective_scoring.get("objective_gap")
        if isinstance(objective_gap, (int, float)):
            scores["objective_gap"] = objective_gap
        objective_progress = objective_scoring.get("objective_progress")
        if isinstance(objective_progress, (int, float)):
            scores["objective_progress"] = objective_progress

        report_dir = Path("output/reports")
        report_dir.mkdir(parents=True, exist_ok=True)
        summary_report_path = report_dir / f"{task_id}.json"

        visualization_artifacts = _extract_visualization_artifacts(context)
        preferred_report_path, report_source = _select_report_path(
            visualization_artifacts,
            report_dir,
            task_id,
        )

        if final_sequence is None:
            final_sequence = context.task.constraints.get("sequence")

        plan_metadata = context.plan.metadata if context.plan else {}
        plan_version = plan_metadata.get("plan_version") or plan_metadata.get("version")

        # De novo 任务：生成专用报告
        de_novo_report_paths = {}
        if _is_de_novo_task(context.task):
            de_novo_report = generate_de_novo_report(context)
            json_path, md_path = write_de_novo_reports(de_novo_report, report_dir)
            de_novo_report_paths = {
                "de_novo_json_path": str(json_path),
                "de_novo_markdown_path": str(md_path),
            }
            # 对于 de novo 任务，优先使用 Markdown 报告
            preferred_report_path = md_path
            report_source = "de_novo_markdown"

        design = DesignResult(
            task_id=task_id,
            sequence=final_sequence,
            structure_pdb_path=structure_pdb_path,  # ESMFold 生成的 PDB 文件
            scores=scores,
            risk_flags=[],
            report_path=str(preferred_report_path),
            metadata={
                "created_at": now_iso(),
                "step_ids": list(context.step_results.keys()),
                "artifacts": visualization_artifacts,
                "summary_report_path": str(summary_report_path),
                "report_source": report_source,
                "plan_metadata": plan_metadata,
                "plan_version": plan_version,
                "execution_steps": execution_steps,
                "objective_scoring": objective_scoring,
                "structure_similarity": structure_similarity,
                **de_novo_report_paths,
            },
        )

        _ = summary_report_path.write_text(design.model_dump_json(indent=2))
        return design


def _extract_visualization_artifacts(context: WorkflowContext) -> dict[str, object]:
    for result in context.step_results.values():
        outputs = result.outputs or {}
        if any(
            key in outputs
            for key in (
                "report_html_path",
                "plotly_html_path",
                "metrics_json_path",
                "assets_dir",
            )
        ):
            return {
                key: outputs.get(key)
                for key in (
                    "metrics_json_path",
                    "plotly_html_path",
                    "report_html_path",
                    "assets_dir",
                    "summary_stats",
                )
                if outputs.get(key) is not None
            }
    return {}


def _select_report_path(
    artifacts: dict[str, object],
    report_dir: Path,
    task_id: str,
) -> tuple[Path, str]:
    report_html_path = artifacts.get("report_html_path")
    if isinstance(report_html_path, str) and report_html_path:
        return Path(report_html_path), "visualization_tool"

    plotly_html_path = artifacts.get("plotly_html_path")
    metrics_json_path = artifacts.get("metrics_json_path")
    normalized_plotly_path = plotly_html_path if isinstance(plotly_html_path, str) else None
    normalized_metrics_path = metrics_json_path if isinstance(metrics_json_path, str) else None
    if normalized_plotly_path or normalized_metrics_path:
        fallback_path = report_dir / f"{task_id}.html"
        _write_fallback_report(
            fallback_path,
            normalized_plotly_path,
            normalized_metrics_path,
        )
        return fallback_path, "visualization_fallback"

    return report_dir / f"{task_id}.json", "summary_json"


def _extract_objective_scoring_summary(context: WorkflowContext) -> dict[str, Any]:
    """从 objective_ranker StepResult 提取可复用的报告摘要。"""

    selected: StepResult | None = None
    for step_result in context.step_results.values():
        outputs = step_result.outputs or {}
        if (
            step_result.tool == "objective_ranker"
            or outputs.get("capability_id") == "objective_scoring"
        ):
            selected = step_result

    if selected is None:
        return {}

    outputs = selected.outputs or {}
    metrics = selected.metrics or {}
    return {
        "step_id": selected.step_id,
        "tool": selected.tool,
        "objective_score": outputs.get("objective_score"),
        "objective_progress": metrics.get("objective_progress"),
        "objective_gap": metrics.get("objective_gap"),
        "score_table": outputs.get("score_table") or [],
        "top_k": outputs.get("top_k") or [],
        "component_scores": outputs.get("component_scores") or {},
        "posterior_score": outputs.get("posterior_score") or {},
        "posterior_scores": outputs.get("posterior_scores") or {},
        "aggregate_score": outputs.get("aggregate_score"),
        "component_weights": outputs.get("component_weights") or {},
        "warnings": outputs.get("warnings") or [],
        "evidence_refs": outputs.get("evidence_refs") or [],
        "rank_reason": outputs.get("rank_reason"),
        "default_recommendation": outputs.get("default_recommendation"),
        "evidence_sufficiency": metrics.get("evidence_sufficiency"),
    }


def _extract_structure_similarity_summary(context: WorkflowContext) -> dict[str, Any]:
    """从 structure similarity StepResult 提取报告与 UI 可复用摘要。"""

    selected: StepResult | None = None
    for step_result in context.step_results.values():
        outputs = step_result.outputs or {}
        if (
            step_result.tool == "foldseek"
            or outputs.get("capability_id") == "structure_similarity_search"
        ):
            selected = step_result

    if selected is None:
        return {}

    outputs = selected.outputs or {}
    hits = outputs.get("structure_similarity_hits")
    if not isinstance(hits, list):
        hits = []
    artifacts = outputs.get("artifact_refs")
    if not isinstance(artifacts, list):
        artifacts = outputs.get("artifacts")
    if not isinstance(artifacts, list):
        artifacts = []
    top_hit = outputs.get("top_hit") if isinstance(outputs.get("top_hit"), dict) else None
    return {
        "step_id": selected.step_id,
        "tool": selected.tool,
        "query_structure": outputs.get("query_structure") or outputs.get("pdb_path"),
        "database": outputs.get("database") or outputs.get("database_path"),
        "hit_count": outputs.get("hit_count") or len(hits),
        "top_hit": top_hit or {},
        "hits": hits[:10],
        "artifact_refs": artifacts,
        "warnings": _structure_similarity_warnings(hits),
    }


def _structure_similarity_warnings(hits: list[Any]) -> list[str]:
    warnings: list[str] = []
    for hit in hits:
        if not isinstance(hit, dict):
            continue
        raw = hit.get("warnings")
        if not isinstance(raw, list):
            continue
        for item in raw:
            if isinstance(item, str) and item not in warnings:
                warnings.append(item)
    return warnings


def _write_fallback_report(
    report_path: Path,
    plotly_html_path: str | None,
    metrics_json_path: str | None,
) -> None:
    plotly_snippet = ""
    if plotly_html_path:
        plotly_snippet = Path(plotly_html_path).read_text(encoding="utf-8")

    metrics_table = _build_metrics_table(metrics_json_path)
    report_html = "\n".join(
        [
            "<!doctype html>",
            '<html lang="en">',
            "<head>",
            '  <meta charset="utf-8" />',
            '  <meta name="viewport" content="width=device-width, initial-scale=1" />',
            "  <title>Visualization Report</title>",
            "  <style>",
            "    body { font-family: Arial, sans-serif; margin: 0; background: #f6f7fb; color: #1d1f27; }",
            "    main { max-width: 1080px; margin: 0 auto; padding: 32px 20px 48px; }",
            "    section { background: #ffffff; border-radius: 12px; padding: 20px; margin-bottom: 24px; box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08); }",
            "    table { border-collapse: collapse; width: 100%; }",
            "    th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #e5e7eb; }",
            "    th { color: #374151; }",
            "  </style>",
            "</head>",
            "<body>",
            "  <main>",
            "    <section>",
            "      <h2>B-factor Trend</h2>",
            plotly_snippet or "<p>No Plotly output available.</p>",
            "    </section>",
            "    <section>",
            "      <h2>Metrics</h2>",
            metrics_table,
            "    </section>",
            "  </main>",
            "</body>",
            "</html>",
        ]
    )
    _ = report_path.write_text(report_html, encoding="utf-8")


def _build_metrics_table(metrics_json_path: str | None) -> str:
    if not metrics_json_path:
        return "<p>No metrics file available.</p>"
    try:
        metrics = json.loads(Path(metrics_json_path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "<p>Failed to load metrics.</p>"

    chain_ids = metrics.get("chain_ids", [])
    residue_count = metrics.get("residue_count", "N/A")
    chain_label = ", ".join(chain_ids) if chain_ids else "N/A"
    return "\n".join(
        [
            "<table>",
            "  <tr><th>Residues</th><td>{}</td></tr>".format(residue_count),
            "  <tr><th>Chains</th><td>{}</td></tr>".format(chain_label),
            f'  <tr><th>Metrics JSON</th><td><a href="{metrics_json_path}">{metrics_json_path}</a></td></tr>',
            "</table>",
        ]
    )


# ============================================================================
# De Novo 设计报告生成逻辑
# ============================================================================

_DE_NOVO_GOAL_TYPE = "de_novo_design"


def _extract_goal_type(task: ProteinDesignTask) -> str:
    """从任务中提取 goal_type（与 planner.py 逻辑保持一致）"""
    for container in (task.constraints, task.metadata):
        goal_block = container.get("goal")
        if isinstance(goal_block, dict):
            goal_type = goal_block.get("type")
            if isinstance(goal_type, str) and goal_type:
                return goal_type
        goal_type = container.get("goal_type")
        if isinstance(goal_type, str) and goal_type:
            return goal_type

    goal_value = task.goal
    stripped = goal_value.strip()
    if stripped == _DE_NOVO_GOAL_TYPE:
        return stripped
    if stripped.startswith("{") and stripped.endswith("}"):
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            return ""
        if isinstance(parsed, dict):
            goal_type = parsed.get("type")
            if isinstance(goal_type, str) and goal_type:
                return goal_type
    return ""


def _is_de_novo_task(task: ProteinDesignTask) -> bool:
    """判断任务是否为 de novo 设计任务"""
    return _extract_goal_type(task) == _DE_NOVO_GOAL_TYPE


def _build_step_summary(step_result: StepResult) -> StepSummary:
    """从 StepResult 构建步骤摘要"""
    # 提取关键输入（过滤掉过长的内容）
    inputs_summary = {}
    for key, value in step_result.inputs.items():
        if isinstance(value, str) and len(value) > 100:
            inputs_summary[key] = f"{value[:50]}... ({len(value)} chars)"
        else:
            inputs_summary[key] = value

    # 提取关键输出
    outputs_summary = {}
    for key, value in step_result.outputs.items():
        if key == "sequence" and isinstance(value, str):
            # 序列截断显示
            if len(value) > 50:
                outputs_summary[key] = f"{value[:20]}...{value[-20:]} ({len(value)} aa)"
            else:
                outputs_summary[key] = value
        elif key == "metrics" and isinstance(value, dict):
            # 提取关键指标
            outputs_summary[key] = {
                k: v
                for k, v in value.items()
                if k in ("plddt_mean", "confidence", "task_id", "tool")
            }
        elif key == "pdb_path":
            outputs_summary[key] = value
        elif key in {
            "score_table",
            "top_k",
            "component_scores",
            "warnings",
            "evidence_refs",
            "rank_reason",
        }:
            outputs_summary[key] = value
        elif isinstance(value, (str, int, float, bool)):
            outputs_summary[key] = value

    return StepSummary(
        step_id=step_result.step_id,
        tool=step_result.tool,
        status=step_result.status,
        inputs_summary=inputs_summary,
        outputs_summary=outputs_summary,
        error_message=step_result.error_message,
    )


def _build_tool_chain_info(context: WorkflowContext) -> ToolChainInfo:
    """从上下文构建工具链信息"""
    sequence_tool = None
    structure_tool = None

    for step_result in context.step_results.values():
        tool = step_result.tool.lower()
        # 识别序列设计工具
        if any(
            kw in tool for kw in ("mpnn", "proteinmpnn", "sequence_design", "esm_if")
        ):
            sequence_tool = step_result.tool
        # 识别结构预测工具
        elif any(kw in tool for kw in ("esmfold", "alphafold", "structure", "fold")):
            structure_tool = step_result.tool

    # 如果没有识别出来，尝试按步骤顺序推断
    if context.plan and len(context.plan.steps) >= 2:
        if sequence_tool is None:
            sequence_tool = context.plan.steps[0].tool
        if structure_tool is None:
            structure_tool = context.plan.steps[1].tool

    description = ""
    if sequence_tool and structure_tool:
        description = f"序列设计({sequence_tool}) → 结构预测({structure_tool})"
    elif sequence_tool:
        description = f"序列设计({sequence_tool})"
    elif structure_tool:
        description = f"结构预测({structure_tool})"

    return ToolChainInfo(
        sequence_design_tool=sequence_tool,
        structure_prediction_tool=structure_tool,
        description=description,
    )


def _build_success_report(context: WorkflowContext) -> SuccessReport:
    """构建成功场景报告"""
    final_sequence = None
    sequence_length = None
    structure_pdb_path = None
    plddt_mean = None
    confidence = None
    objective_scoring = _extract_objective_scoring_summary(context)
    structure_similarity = _extract_structure_similarity_summary(context)

    for step_result in context.step_results.values():
        outputs = step_result.outputs or {}

        # 提取序列
        if "sequence" in outputs:
            final_sequence = outputs["sequence"]
            sequence_length = len(final_sequence)

        # 提取结构预测结果
        if "pdb_path" in outputs:
            structure_pdb_path = outputs["pdb_path"]
            # 提取该步骤的指标
            metrics = outputs.get("metrics", {})
            if "plddt_mean" in metrics:
                plddt_mean = metrics["plddt_mean"]
            if "confidence" in metrics:
                confidence = metrics["confidence"]

    return SuccessReport(
        final_sequence=final_sequence,
        sequence_length=sequence_length,
        structure_pdb_path=structure_pdb_path,
        plddt_mean=plddt_mean,
        confidence=confidence,
        objective_score=objective_scoring.get("objective_score"),
        objective_top_k=objective_scoring.get("top_k") or [],
        component_scores=objective_scoring.get("component_scores") or {},
        objective_warnings=objective_scoring.get("warnings") or [],
        evidence_refs=objective_scoring.get("evidence_refs") or [],
        posterior_score=objective_scoring.get("posterior_score") or {},
        rank_reason=objective_scoring.get("rank_reason"),
        structure_similarity=structure_similarity,
    )


def _build_failure_report(context: WorkflowContext) -> FailureReport:
    """构建失败场景报告"""
    failed_step_id = None
    failed_tool = None
    failure_type = None
    error_message = None
    safety_action = None
    safety_reason = None
    suggested_next_steps = []

    # 查找失败的步骤
    for step_result in context.step_results.values():
        if step_result.status == "failed":
            failed_step_id = step_result.step_id
            failed_tool = step_result.tool
            failure_type = step_result.failure_type
            error_message = step_result.error_message
            break

    # 从安全事件中提取信息
    for safety_event in context.safety_events:
        if safety_event.action in ("warn", "block"):
            safety_action = safety_event.action
            # 提取安全风险原因
            for flag in safety_event.risk_flags:
                if flag.level in ("warn", "block"):
                    safety_reason = flag.message
                    break
            break

    # 生成建议的下一步
    if failure_type == "tool_execution_error":
        suggested_next_steps.append("检查工具配置和依赖环境")
        suggested_next_steps.append("尝试使用备用工具执行")
    elif failure_type == "validation_error":
        suggested_next_steps.append("检查输入参数是否符合约束")
        suggested_next_steps.append("调整设计目标或约束条件")
    elif safety_action == "block":
        suggested_next_steps.append("审查安全策略并调整输入")
        suggested_next_steps.append("联系管理员解除安全限制")
    else:
        suggested_next_steps.append("查看详细日志分析失败原因")
        suggested_next_steps.append("考虑使用 replan 功能重新规划")

    return FailureReport(
        failed_step_id=failed_step_id,
        failed_tool=failed_tool,
        failure_type=failure_type,
        error_message=error_message,
        safety_action=safety_action,
        safety_reason=safety_reason,
        suggested_next_steps=suggested_next_steps,
    )


def _determine_task_status(context: WorkflowContext) -> str:
    """判断任务最终状态"""
    has_failed = False
    has_success = False

    for step_result in context.step_results.values():
        if step_result.status == "failed":
            has_failed = True
        elif step_result.status == "success":
            has_success = True

    # 检查安全事件是否导致阻断
    for safety_event in context.safety_events:
        if safety_event.action == "block":
            return "failed"

    if has_failed:
        return "failed" if not has_success else "partial"
    return "success"


def generate_de_novo_report(context: WorkflowContext) -> DeNovoReport:
    """生成 de novo 设计任务的结构化报告"""
    task = context.task
    status = _determine_task_status(context)

    # 构建步骤摘要
    step_summaries = []
    if context.plan:
        for plan_step in context.plan.steps:
            step_result = context.step_results.get(plan_step.id)
            if step_result:
                step_summaries.append(_build_step_summary(step_result))
    else:
        for step_result in context.step_results.values():
            step_summaries.append(_build_step_summary(step_result))

    # 根据状态构建成功或失败报告
    success_report = None
    failure_report = None
    if status == "success":
        success_report = _build_success_report(context)
    else:
        failure_report = _build_failure_report(context)
        # 部分成功时也包含成功部分
        if status == "partial":
            success_report = _build_success_report(context)

    return DeNovoReport(
        task_id=task.task_id,
        task_description=task.goal,
        design_goal=_extract_goal_type(task) or "de_novo_design",
        created_at=now_iso(),
        status=status,
        tool_chain=_build_tool_chain_info(context),
        step_summaries=step_summaries,
        success_report=success_report,
        failure_report=failure_report,
    )


def _render_de_novo_markdown(report: DeNovoReport) -> str:
    """将 DeNovoReport 渲染为 Markdown 格式。"""

    return render_de_novo_markdown(cast(DeNovoReportView, cast(object, report)))


def write_de_novo_reports(
    report: DeNovoReport,
    report_dir: Path,
) -> tuple[Path, Path]:
    """写入 de novo 报告文件（JSON 和 Markdown）

    Returns:
        (json_path, markdown_path): 两个报告文件的路径
    """
    report_dir.mkdir(parents=True, exist_ok=True)

    json_path = report_dir / f"{report.task_id}_denovo.json"
    md_path = report_dir / f"{report.task_id}_denovo.md"

    # 写入 JSON
    _ = json_path.write_text(report.model_dump_json(indent=2), encoding="utf-8")

    # 写入 Markdown
    md_content = _render_de_novo_markdown(report)
    _ = md_path.write_text(md_content, encoding="utf-8")

    return json_path, md_path
