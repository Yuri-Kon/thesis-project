"""Integration tests for EventLog integration in workflow.

This module verifies that WAITING_ENTER, WAITING_EXIT, and DECISION_APPLIED
events are properly logged during state transitions and decision application.
"""
import json
from pathlib import Path

import pytest

from src.models.contracts import (
    ACTION_SCORE_METADATA_KEY,
    CAPABILITY_READINESS_METADATA_KEY,
    DEFAULT_RECOMMENDATION_REASON_METADATA_KEY,
    Decision,
    DecisionChoice,
    PendingActionStatus,
    PendingActionType,
    ProteinDesignTask,
    RUNTIME_STATE_SUMMARY_METADATA_KEY,
    SHADOW_SCORE_METADATA_KEY,
    TOOL_READINESS_METADATA_KEY,
    WAITING_RUNTIME_SUMMARY_METADATA_KEY,
)
from src.models.db import ExternalStatus, InternalStatus, TaskRecord
from src.models.event_log import EventType
from src.workflow.context import WorkflowContext
from src.workflow.decision_apply import apply_plan_confirm_decision
from src.workflow.pending_action import build_pending_action, enter_waiting_state
from src.storage.log_store import DEFAULT_LOG_DIR


@pytest.fixture
def cleanup_logs():
    """Cleanup test logs after test."""
    yield
    # Clean up test log files
    if DEFAULT_LOG_DIR.exists():
        for log_file in DEFAULT_LOG_DIR.glob("test_*.jsonl"):
            log_file.unlink()


def test_enter_waiting_state_emits_waiting_enter_event(cleanup_logs):
    """Test that enter_waiting_state emits WAITING_ENTER EventLog."""
    task = ProteinDesignTask(
        task_id="test_enter_waiting_001",
        goal="test enter waiting state logging",
        constraints={},
        metadata={},
    )
    context = WorkflowContext(
        task=task,
        status=InternalStatus.PLANNING,
        plan=None,
        step_results={},
        design_result=None,
        safety_events=[],
        pending_action=None,
    )
    record = TaskRecord(
        id=task.task_id,
        goal=task.goal,
        status=ExternalStatus.PLANNING,
        internal_status=InternalStatus.PLANNING,
        plan=None,
        pending_action=None,
        design_result=None,
    )

    # Build and enter WAITING_PLAN_CONFIRM state
    from src.models.contracts import PendingActionCandidate, Plan, PlanStep

    candidate_plan = Plan(
        task_id=task.task_id,
        steps=[
            PlanStep(
                id="S1",
                tool="dummy_tool",
                inputs={"sequence": "ACDE"},
                metadata={},
            )
        ],
        constraints={},
        metadata={},
    )
    pending_action = build_pending_action(
        task_id=task.task_id,
        action_type=PendingActionType.PLAN_CONFIRM,
        candidates=[
            PendingActionCandidate(
                candidate_id="candidate_waiting",
                payload=candidate_plan,
                metadata={
                    RUNTIME_STATE_SUMMARY_METADATA_KEY: {
                        "schema_version": 1,
                        "p_success": 0.77,
                        "p_structural_failure": 0.12,
                        "recovery_margin": 0.44,
                        "expected_remaining_cost": 2.5,
                    },
                    DEFAULT_RECOMMENDATION_REASON_METADATA_KEY: {
                        "code": "plan_ranked_first",
                        "message": "selected by deterministic rank",
                    },
                    ACTION_SCORE_METADATA_KEY: {
                        "value": 0.77,
                        "source": "score_breakdown.overall",
                    },
                    SHADOW_SCORE_METADATA_KEY: {
                        "value": 0.77,
                        "source": "score_breakdown.overall_passthrough",
                    },
                    TOOL_READINESS_METADATA_KEY: {
                        "tool_id": "dummy_tool",
                        "status": "degraded",
                        "reason": "healthcheck warning",
                    },
                    CAPABILITY_READINESS_METADATA_KEY: {
                        "capability_id": "sequence_generation",
                        "status": "degraded",
                        "source": "capability_readiness_matrix",
                        "selected_tool_id": "dummy_tool",
                        "degraded_reasons": ["dummy_tool: healthcheck warning"],
                    },
                },
            )
        ],
        default_recommendation="candidate_waiting",
        explanation="test waiting enter",
    )
    enter_waiting_state(
        context,
        record,
        pending_action,
        InternalStatus.WAITING_PLAN_CONFIRM,
        reason="test_enter_waiting",
    )

    # Read the log file
    log_file = DEFAULT_LOG_DIR / f"{task.task_id}.jsonl"
    assert log_file.exists(), "Log file should be created"

    # Parse all log entries
    log_entries = []
    with log_file.open("r") as f:
        for line in f:
            log_entries.append(json.loads(line))

    # Find WAITING_ENTER event
    waiting_enter_events = [
        e for e in log_entries if e.get("event_type") == EventType.WAITING_ENTER.value
    ]
    assert len(waiting_enter_events) == 1, "Should have exactly one WAITING_ENTER event"

    event = waiting_enter_events[0]
    assert event["task_id"] == task.task_id
    assert event["pending_action_id"] == pending_action.pending_action_id
    assert event["prev_status"] == ExternalStatus.PLANNING.value
    assert event["new_status"] == ExternalStatus.WAITING_PLAN_CONFIRM.value
    assert event["internal_status"] == InternalStatus.WAITING_PLAN_CONFIRM.value
    assert event["data"]["waiting_state"] == InternalStatus.WAITING_PLAN_CONFIRM.value
    waiting_summary = event["data"][WAITING_RUNTIME_SUMMARY_METADATA_KEY]
    assert waiting_summary["selected_candidate_id"] == "candidate_waiting"
    assert waiting_summary["default_recommendation"] == "candidate_waiting"
    assert waiting_summary[ACTION_SCORE_METADATA_KEY]["value"] == pytest.approx(0.77)
    assert event["data"]["action_name"] == "plan"
    assert event["data"]["action_score"]["value"] == pytest.approx(0.77)
    assert event["data"]["shadow_score"]["value"] == pytest.approx(0.77)
    assert event["data"]["evidence_source"]["code"] == "plan_ranked_first"
    assert event["data"]["tool_readiness"]["tool_id"] == "dummy_tool"
    assert (
        event["data"]["capability_readiness"]["source"]
        == "capability_readiness_matrix"
    )
    assert event["data"]["runtime_state_summary"]["p_success"] == pytest.approx(0.5)
    assert pending_action.metadata[WAITING_RUNTIME_SUMMARY_METADATA_KEY]["default_recommendation_reason"]["code"] == "plan_ranked_first"
    assert event["actor_type"] == "system"


def test_decision_apply_emits_waiting_exit_and_decision_applied(cleanup_logs):
    """Test that applying a decision emits both WAITING_EXIT and DECISION_APPLIED events."""
    task = ProteinDesignTask(
        task_id="test_decision_apply_002",
        goal="test decision apply logging",
        constraints={},
        metadata={},
    )
    context = WorkflowContext(
        task=task,
        status=InternalStatus.WAITING_PLAN_CONFIRM,
        plan=None,
        step_results={},
        design_result=None,
        safety_events=[],
        pending_action=None,
    )
    record = TaskRecord(
        id=task.task_id,
        goal=task.goal,
        status=ExternalStatus.WAITING_PLAN_CONFIRM,
        internal_status=InternalStatus.WAITING_PLAN_CONFIRM,
        plan=None,
        pending_action=None,
        design_result=None,
    )

    # Build pending action with a candidate plan
    from src.models.contracts import Plan, PlanStep, PendingActionCandidate

    candidate_plan = Plan(
        task_id=task.task_id,
        steps=[
            PlanStep(
                id="S1",
                tool="dummy_tool",
                inputs={"sequence": "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQLR"},
                metadata={},
            )
        ],
        constraints={},
        metadata={},
    )
    pending_action = build_pending_action(
        task_id=task.task_id,
        action_type=PendingActionType.PLAN_CONFIRM,
        candidates=[
            PendingActionCandidate(
                candidate_id="candidate_1",
                payload=candidate_plan,
                summary="test plan",
                score_breakdown={},
                metadata={
                    ACTION_SCORE_METADATA_KEY: {
                        "value": 0.66,
                        "source": "candidate.overall",
                    },
                    SHADOW_SCORE_METADATA_KEY: {
                        "value": 0.61,
                        "source": "candidate.shadow",
                    },
                    DEFAULT_RECOMMENDATION_REASON_METADATA_KEY: {
                        "code": "human_selected_default",
                        "message": "default candidate selected",
                    },
                },
            )
        ],
        default_suggestion="candidate_1",
        explanation="test decision apply",
    )
    context.pending_action = pending_action
    record.pending_action = pending_action

    # Apply decision to accept the plan
    decision = Decision(
        decision_id="decision_001",
        task_id=task.task_id,
        pending_action_id=pending_action.pending_action_id,
        choice=DecisionChoice.ACCEPT,
        selected_candidate_id="candidate_1",
        decided_by="test_user",
    )

    apply_plan_confirm_decision(context, record, decision)

    # Read the log file
    log_file = DEFAULT_LOG_DIR / f"{task.task_id}.jsonl"
    assert log_file.exists(), "Log file should be created"

    # Parse all log entries
    log_entries = []
    with log_file.open("r") as f:
        for line in f:
            log_entries.append(json.loads(line))

    # Find DECISION_APPLIED event
    decision_applied_events = [
        e
        for e in log_entries
        if e.get("event_type") == EventType.DECISION_APPLIED.value
    ]
    assert (
        len(decision_applied_events) == 1
    ), "Should have exactly one DECISION_APPLIED event"

    decision_event = decision_applied_events[0]
    assert decision_event["task_id"] == task.task_id
    assert decision_event["decision_id"] == decision.decision_id
    assert decision_event["pending_action_id"] == pending_action.pending_action_id
    assert decision_event["prev_status"] == ExternalStatus.WAITING_PLAN_CONFIRM.value
    assert decision_event["new_status"] == ExternalStatus.PLANNED.value
    assert decision_event["data"]["choice"] == DecisionChoice.ACCEPT.value
    assert decision_event["data"]["action_name"] == "plan"
    assert decision_event["data"]["action_score"]["value"] == pytest.approx(0.66)
    assert decision_event["data"]["shadow_score"]["value"] == pytest.approx(0.61)
    assert decision_event["data"]["evidence_source"]["code"] == "human_selected_default"
    assert decision_event["data"]["runtime_state_summary"]["p_success"] == pytest.approx(0.5)
    assert decision_event["actor_type"] == "human"

    # Find WAITING_EXIT event
    waiting_exit_events = [
        e for e in log_entries if e.get("event_type") == EventType.WAITING_EXIT.value
    ]
    assert len(waiting_exit_events) == 1, "Should have exactly one WAITING_EXIT event"

    exit_event = waiting_exit_events[0]
    assert exit_event["task_id"] == task.task_id
    assert exit_event["pending_action_id"] == pending_action.pending_action_id
    assert exit_event["prev_status"] == ExternalStatus.WAITING_PLAN_CONFIRM.value
    assert exit_event["new_status"] == ExternalStatus.PLANNED.value
    assert (
        exit_event["data"]["waiting_state"] == InternalStatus.WAITING_PLAN_CONFIRM.value
    )
    assert exit_event["data"]["action_status"] == PendingActionStatus.DECIDED.value
    assert exit_event["data"]["action_name"] == "plan"
    assert exit_event["data"]["action_score"]["value"] == pytest.approx(0.66)
    assert exit_event["data"]["shadow_score"]["value"] == pytest.approx(0.61)
    assert exit_event["data"]["evidence_source"]["code"] == "human_selected_default"
    assert exit_event["data"]["runtime_state_summary"]["p_success"] == pytest.approx(0.5)


def test_fsm_reconstruction_from_logs(cleanup_logs):
    """Test that logs can reconstruct FSM state transitions."""
    task = ProteinDesignTask(
        task_id="test_fsm_reconstruction_003",
        goal="test FSM reconstruction from logs",
        constraints={},
        metadata={},
    )
    context = WorkflowContext(
        task=task,
        status=InternalStatus.PLANNING,
        plan=None,
        step_results={},
        design_result=None,
        safety_events=[],
        pending_action=None,
    )

    # Build and enter WAITING_PLAN_CONFIRM
    pending_action = build_pending_action(
        task_id=task.task_id,
        action_type=PendingActionType.PLAN_CONFIRM,
        candidates=[],
        explanation="test FSM reconstruction",
    )
    enter_waiting_state(
        context,
        None,
        pending_action,
        InternalStatus.WAITING_PLAN_CONFIRM,
        reason="entering_waiting_for_plan",
    )

    # Read the log file and verify we can reconstruct the state machine
    log_file = DEFAULT_LOG_DIR / f"{task.task_id}.jsonl"
    log_entries = []
    with log_file.open("r") as f:
        for line in f:
            log_entries.append(json.loads(line))

    # Extract state transitions from logs
    state_transitions = []
    for entry in log_entries:
        if entry.get("event") == "TASK_STATUS_CHANGED":
            state_transitions.append(
                (entry["from_status"], entry["to_status"], entry.get("reason"))
            )
        elif entry.get("event_type") == EventType.WAITING_ENTER.value:
            state_transitions.append(
                (
                    entry["prev_status"],
                    entry["new_status"],
                    "WAITING_ENTER",
                )
            )

    # Verify we can see the state transition sequence
    assert len(state_transitions) >= 1, "Should have at least one state transition"

    # Verify WAITING_ENTER is present in the log
    waiting_transitions = [
        t for t in state_transitions if t[2] == "WAITING_ENTER"
    ]
    assert len(waiting_transitions) == 1, "Should have exactly one WAITING_ENTER transition"
    assert waiting_transitions[0][0] == ExternalStatus.PLANNING.value
    assert waiting_transitions[0][1] == ExternalStatus.WAITING_PLAN_CONFIRM.value


def test_terminal_stop_audit_chain_is_recorded_in_event_log(cleanup_logs):
    """TC-S13: 验证 terminal_stop 的完整审计链被记录到 EventLog。

    前提：在 WAITING_REPLAN 状态下接受 terminal_stop 候选。
    预期：
      - 事件日志包含 WAITING_ENTER (replan_confirm) 和 DECISION_APPLIED
      - DECISION_APPLIED 记录 terminal_policy / terminal_reason / replan_mode
      - 状态迁移到 FAILED 并写入 FAILED_ENTER
    """
    from src.models.contracts import PendingActionCandidate, Plan, PlanStep, PlanPatch
    from src.workflow.decision_apply import apply_replan_confirm_decision

    task = ProteinDesignTask(
        task_id="test_terminal_stop_audit",
        goal="verify terminal_stop audit chain in event log",
        constraints={
            "structural_failure": True,
            "require_replan_confirm": True,
        },
        metadata={},
    )
    # 构建一个 suffix_replan 的 terminal_stop plan
    stop_plan = Plan(
        task_id=task.task_id,
        steps=[
            PlanStep(id="S1", tool="esmfold", inputs={"sequence": "ACDE"}, metadata={}),
        ],
        constraints={"require_replan_confirm": True},
        metadata={
            "replan_mode": "suffix_replan",
            "terminal_policy": "stop",
            "terminal_reason": "economic_stop",
            "failure_context": {
                "original_failure_step": "S2",
                "budget_consumed_pct": 92.0,
            },
        },
    )
    pending_action = build_pending_action(
        task_id=task.task_id,
        action_type=PendingActionType.REPLAN_CONFIRM,
        candidates=[
            PendingActionCandidate(
                candidate_id="terminal_stop_c1",
                payload=stop_plan,
                structured_payload=stop_plan,
                metadata={
                    "terminal_policy": "stop",
                    "terminal_reason": "economic_stop",
                    "replan_mode": "suffix_replan",
                },
            )
        ],
        explanation="structural failure triggered replan with terminal_stop option",
        default_recommendation="terminal_stop_c1",
    )

    record = TaskRecord(
        id=task.task_id,
        goal=task.goal,
        status=ExternalStatus.WAITING_REPLAN_CONFIRM,
        internal_status=InternalStatus.WAITING_REPLAN,
        plan=stop_plan,
        pending_action=pending_action,
        design_result=None,
    )

    context = WorkflowContext(
        task=task,
        status=InternalStatus.WAITING_REPLAN,
        pending_action=pending_action,
    )

    # 进入等待态，记录 WAITING_ENTER
    enter_waiting_state(
        context,
        record,
        pending_action,
        InternalStatus.WAITING_REPLAN,
        reason="structural failure triggered terminal_stop review",
    )

    decision = Decision(
        decision_id="dec_terminal_stop_audit",
        task_id=task.task_id,
        pending_action_id=pending_action.pending_action_id,
        choice=DecisionChoice.ACCEPT,
        selected_candidate_id="terminal_stop_c1",
        decided_by="safety_operator",
    )

    result = apply_replan_confirm_decision(context, record, decision)

    # 验证结果
    assert context.status == InternalStatus.FAILED
    assert record.status == ExternalStatus.FAILED
    assert pending_action.status == PendingActionStatus.DECIDED

    # 读取事件日志并验证审计链
    log_path = DEFAULT_LOG_DIR / f"{task.task_id}.jsonl"
    assert log_path.exists(), "事件日志文件应已创建"
    events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines() if line.strip()]

    waiting_enter_events = [e for e in events if e.get("event_type") == EventType.WAITING_ENTER.value]
    assert len(waiting_enter_events) == 1, "应包含 1 条 WAITING_ENTER"
    assert waiting_enter_events[0]["data"]["waiting_state"] == InternalStatus.WAITING_REPLAN.value
    assert waiting_enter_events[0]["data"]["action_type"] == PendingActionType.REPLAN_CONFIRM.value

    decision_events = [e for e in events if e.get("event_type") == EventType.DECISION_APPLIED.value]
    assert len(decision_events) == 1, "应包含 1 条 DECISION_APPLIED"
    dec_data = decision_events[0]["data"]
    assert dec_data["choice"] == DecisionChoice.ACCEPT.value
    assert dec_data.get("terminal_policy") == "stop"
    assert dec_data.get("terminal_reason") == "economic_stop"

    waiting_exit_events = [e for e in events if e.get("event_type") == EventType.WAITING_EXIT.value]
    assert len(waiting_exit_events) == 1, "应包含 1 条 WAITING_EXIT"
    assert waiting_exit_events[0]["new_status"] == ExternalStatus.FAILED.value

    # 验证决策元数据通过快照持久化
    assert result.plan is None, "terminal_stop 不应返回新 plan（直接标记失败）"

    # 验证完整的审计链：WAITING_ENTER → DECISION_APPLIED → WAITING_EXIT
    state_transitions = [
        (e.get("prev_status"), e.get("new_status"), e.get("event_type"))
        for e in events
        if e.get("event_type") in {
            EventType.WAITING_ENTER.value,
            EventType.WAITING_EXIT.value,
            EventType.DECISION_APPLIED.value,
        }
    ]
    assert len(state_transitions) >= 3, (
        f"审计链应至少包含 WAITING_ENTER → DECISION_APPLIED → WAITING_EXIT "
        f"三段转换，实际 {len(state_transitions)} 段: {state_transitions}"
    )
