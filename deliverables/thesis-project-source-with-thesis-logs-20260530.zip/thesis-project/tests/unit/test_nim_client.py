from __future__ import annotations

from unittest.mock import Mock

import httpx
import pytest

from src.engines.nim_client import NvidiaNIMClient
from src.workflow.errors import FailureType, StepRunError


def test_call_sync_success_builds_request() -> None:
    mock_response = Mock()
    mock_response.raise_for_status = Mock()
    mock_response.json.return_value = {"pdb": "ATOM", "plddt": 42.0}

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="test-token",
        client=mock_client,
    )

    payload = {"sequence": "ACDEFG"}
    data = client.call_sync(payload)

    assert data["pdb"] == "ATOM"
    mock_client.post.assert_called_once()
    _, kwargs = mock_client.post.call_args
    assert kwargs["json"] == payload
    assert kwargs["headers"]["Authorization"] == "Bearer test-token"


def test_call_sync_missing_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("NIM_API_KEY", raising=False)
    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key=None,
        client=Mock(),
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.NON_RETRYABLE
    assert exc_info.value.code == "NIM_AUTH_FAILED"


def test_call_sync_http_5xx() -> None:
    mock_response = Mock()
    mock_response.status_code = 500
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Server error",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.RETRYABLE
    assert exc_info.value.code == "NIM_MODEL_ERROR"


def test_call_sync_http_4xx() -> None:
    mock_response = Mock()
    mock_response.status_code = 400
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Client error",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.NON_RETRYABLE
    assert exc_info.value.code == "NIM_INVALID_INPUT"


@pytest.mark.parametrize("status_code", [401, 403])
def test_call_sync_http_auth_failed(status_code: int) -> None:
    mock_response = Mock()
    mock_response.status_code = status_code
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Auth failed",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.NON_RETRYABLE
    assert exc_info.value.code == "NIM_AUTH_FAILED"


def test_call_sync_http_quota_exceeded() -> None:
    mock_response = Mock()
    mock_response.status_code = 429
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Rate limited",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.RETRYABLE
    assert exc_info.value.code == "NIM_QUOTA_EXCEEDED"


def test_call_sync_http_model_not_found() -> None:
    mock_response = Mock()
    mock_response.status_code = 404
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Model missing",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.NON_RETRYABLE
    assert exc_info.value.code == "NIM_MODEL_NOT_FOUND"


def test_call_sync_http_invalid_input() -> None:
    mock_response = Mock()
    mock_response.status_code = 422
    mock_response.text = '{"detail":"sequence must be a string"}'
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Invalid input",
        request=Mock(),
        response=mock_response,
    )

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.NON_RETRYABLE
    assert exc_info.value.code == "NIM_INVALID_INPUT"
    assert "sequence must be a string" in str(exc_info.value)


def test_call_sync_timeout() -> None:
    mock_client = Mock()
    mock_client.post.side_effect = httpx.TimeoutException("timeout")

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.RETRYABLE
    assert exc_info.value.code == "NIM_TIMEOUT"


def test_call_sync_invalid_json() -> None:
    mock_response = Mock()
    mock_response.raise_for_status = Mock()
    mock_response.json.side_effect = ValueError("bad json")

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    client = NvidiaNIMClient(
        base_url="https://health.api.nvidia.com/v1/biology/nvidia/esmfold",
        api_key="token",
        client=mock_client,
    )

    with pytest.raises(StepRunError) as exc_info:
        client.call_sync({"sequence": "ACDEFG"})

    assert exc_info.value.failure_type == FailureType.TOOL_ERROR
    assert exc_info.value.code == "NIM_INVALID_RESPONSE"


def test_call_sync_uses_provider_config_defaults(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    mock_response = Mock()
    mock_response.raise_for_status = Mock()
    mock_response.json.return_value = {"pdb": "ATOM", "plddt": 42.0}

    mock_client = Mock()
    mock_client.post.return_value = mock_response

    monkeypatch.setenv("NIM_API_KEY", "test-token")
    client = NvidiaNIMClient(client=mock_client)

    payload = {"sequence": "ACDEFG"}
    client.call_sync(payload)

    mock_client.post.assert_called_once()
    args, kwargs = mock_client.post.call_args
    assert args[0] == "https://health.api.nvidia.com/v1/biology/nvidia/esmfold"
    assert kwargs["headers"]["Authorization"] == "Bearer test-token"
