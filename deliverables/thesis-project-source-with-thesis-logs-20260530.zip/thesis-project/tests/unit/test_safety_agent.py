"""
测试 SafetyAgent 的接口和伪实现
"""
import pytest

from src.models.contracts import (
    ProteinDesignTask,
    Plan,
    PlanStep,
    StepResult,
    DesignResult,
    SafetyResult,
    RiskFlag,
    now_iso,
)

from src.agents.safety import SafetyAgent
from src.workflow.context import WorkflowContext
from src.models.db import InternalStatus


@pytest.fixture
def dummy_task() -> ProteinDesignTask:
    return ProteinDesignTask(
        task_id="task-001",
        goal="demo-goal",
        constraints={},
        metadata={},
    )


@pytest.fixture
def dummy_plan(dummy_task: ProteinDesignTask) -> Plan:
    step = PlanStep(
        id="S1",
        tool="dummy_tool",
        inputs={"x": 1},
        metadata={},
    )
    return Plan(
        task_id=dummy_task.task_id,
        steps=[step],
        constraints={},
        metadata={},
    )


@pytest.fixture
def dummy_context(dummy_task: ProteinDesignTask) -> WorkflowContext:
    return WorkflowContext(
        task=dummy_task,
        plan=None,
        step_results={},
        safety_events=[],
        design_result=None,
            status=InternalStatus.CREATED,
    )


@pytest.fixture
def safety_agent() -> SafetyAgent:
    return SafetyAgent()


class TestSafetyAgent:
    """测试 SafetyAgent 的接口和伪实现"""

    def test_check_task_input_returns_safety_result(
        self, safety_agent: SafetyAgent, dummy_task: ProteinDesignTask
    ):
        """测试：check_task_input 返回 SafetyResult"""
        result = safety_agent.check_task_input(dummy_task)
        
        assert isinstance(result, SafetyResult)
        assert result.task_id == dummy_task.task_id
        assert result.phase == "input"
        assert result.scope == "task"
        assert result.action == "allow"
        assert result.risk_flags == []
        assert result.timestamp is not None

    def test_check_task_input_with_plan(
        self, safety_agent: SafetyAgent, dummy_task: ProteinDesignTask, dummy_plan: Plan
    ):
        """测试：check_task_input 可以接受可选的 plan 参数"""
        result = safety_agent.check_task_input(dummy_task, dummy_plan)
        
        assert isinstance(result, SafetyResult)
        assert result.phase == "input"

    def test_check_pre_step_returns_safety_result(
        self, safety_agent: SafetyAgent, dummy_context: WorkflowContext, dummy_plan: Plan
    ):
        """测试：check_pre_step 返回 SafetyResult"""
        step = dummy_plan.steps[0]
        result = safety_agent.check_pre_step(step, dummy_context)
        
        assert isinstance(result, SafetyResult)
        assert result.task_id == dummy_context.task.task_id
        assert result.phase == "step"
        assert result.scope == f"step:{step.id}"
        assert result.action == "allow"
        assert result.risk_flags == []
        assert result.timestamp is not None

    def test_check_post_step_returns_safety_result(
        self,
        safety_agent: SafetyAgent,
        dummy_context: WorkflowContext,
        dummy_plan: Plan,
    ):
        """测试：check_post_step 返回 SafetyResult"""
        step = dummy_plan.steps[0]
        step_result = StepResult(
            task_id=dummy_context.task.task_id,
            step_id=step.id,
            tool=step.tool,
            status="success",
            failure_type=None,
            error_message=None,
            error_details={},
            outputs={"dummy": "output"},
            metrics={},
            risk_flags=[],
            logs_path=None,
            timestamp=now_iso(),
        )
        
        result = safety_agent.check_post_step(step, step_result, dummy_context)
        
        assert isinstance(result, SafetyResult)
        assert result.task_id == dummy_context.task.task_id
        assert result.phase == "step"
        assert result.scope == f"step:{step.id}"
        assert result.action == "allow"
        assert result.risk_flags == []
        assert result.timestamp is not None

    def test_check_final_result_returns_safety_result(
        self, safety_agent: SafetyAgent, dummy_context: WorkflowContext
    ):
        """测试：check_final_result 返回 SafetyResult"""
        result = safety_agent.check_final_result(dummy_context)
        
        assert isinstance(result, SafetyResult)
        assert result.task_id == dummy_context.task.task_id
        assert result.phase == "output"
        assert result.scope == "result"
        assert result.action == "allow"
        assert result.risk_flags == []
        assert result.timestamp is not None

    def test_check_final_result_with_design_result(
        self, safety_agent: SafetyAgent, dummy_context: WorkflowContext
    ):
        """测试：check_final_result 可以接受可选的 design_result 参数"""
        design_result = DesignResult(
            task_id=dummy_context.task.task_id,
            sequence="MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQLR",
            structure_pdb_path=None,
            scores={},
            risk_flags=[],
            report_path="/path/to/report.json",
            metadata={},
        )
        
        result = safety_agent.check_final_result(dummy_context, design_result)
        
        assert isinstance(result, SafetyResult)
        assert result.phase == "output"

    def test_check_post_step_s3_partial_reject_returns_warn(
        self,
        safety_agent: SafetyAgent,
        dummy_context: WorkflowContext,
    ):
        step = PlanStep(
            id="S3",
            tool="biopython_qc",
            inputs={},
            metadata={"stage_id": "S3"},
        )
        step_result = StepResult(
            task_id=dummy_context.task.task_id,
            step_id="S3",
            tool="biopython_qc",
            status="success",
            failure_type=None,
            error_message=None,
            error_details={},
            outputs={
                "stage_id": "S3",
                "pass_count": 1,
                "fail_count": 2,
                "failed_samples": [
                    {"candidate_id": "bad_1", "reject_codes": ["S3_SEQUENCE_INVALID_CHAR"]}
                ],
            },
            metrics={},
            risk_flags=[],
            logs_path=None,
            timestamp=now_iso(),
        )

        result = safety_agent.check_post_step(step, step_result, dummy_context)

        assert result.action == "warn"
        assert len(result.risk_flags) == 1
        assert result.risk_flags[0].code == "S3_PARTIAL_QUALITY_GATE_FAIL"
        assert result.risk_flags[0].level == "warn"

    def test_check_post_step_s3_all_rejected_returns_block(
        self,
        safety_agent: SafetyAgent,
        dummy_context: WorkflowContext,
    ):
        step = PlanStep(
            id="S3",
            tool="biopython_qc",
            inputs={},
            metadata={"stage_id": "S3"},
        )
        step_result = StepResult(
            task_id=dummy_context.task.task_id,
            step_id="S3",
            tool="biopython_qc",
            status="success",
            failure_type=None,
            error_message=None,
            error_details={},
            outputs={
                "stage_id": "S3",
                "pass_count": 0,
                "fail_count": 3,
                "failed_samples": [
                    {"candidate_id": "bad_1", "reject_codes": ["S3_PLDDT_BELOW_THRESHOLD"]}
                ],
            },
            metrics={},
            risk_flags=[],
            logs_path=None,
            timestamp=now_iso(),
        )

        result = safety_agent.check_post_step(step, step_result, dummy_context)

        assert result.action == "block"
        assert len(result.risk_flags) == 1
        assert result.risk_flags[0].code == "S3_ALL_CANDIDATES_REJECTED"

    def test_pre_step_block_deterministic_forbidden_motif(
        self,
        dummy_context: WorkflowContext,
    ):
        """pre_step 确定性阻断：当安全规则检测到 forbidden motif 时返回 block

        不依赖 LLM，纯规则判定。阻断时：
        - action == "block"
        - risk_flags 包含 FORBIDDEN_MOTIF_PRESENT
        - timestamp 非空
        """
        step = PlanStep(
            id="S1",
            tool="protgpt2",
            inputs={"sequence": "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQLR"},
            metadata={"constraints": {"forbidden_motifs": ["MKTA"]}},
        )

        # 确定性安全检查：pre_step 检测 step metadata 中的 forbidden_motifs
        class ForbiddenMotifSafetyAgent(SafetyAgent):
            def check_pre_step(self, step, context):
                meta = step.metadata if isinstance(step.metadata, dict) else {}
                motifs = meta.get("constraints", {}).get("forbidden_motifs", [])
                inputs = step.inputs if isinstance(step.inputs, dict) else {}
                seq = inputs.get("sequence", "")
                for motif in motifs:
                    if isinstance(motif, str) and isinstance(seq, str) and motif.upper() in seq.upper():
                        return SafetyResult(
                            task_id=context.task.task_id,
                            phase="step",
                            scope=f"step:{step.id}",
                            action="block",
                            risk_flags=[RiskFlag(
                                code="FORBIDDEN_MOTIF_PRESENT",
                                level="block",
                                scope="step",
                                message=f"Forbidden motif '{motif}' detected in sequence",
                            )],
                            timestamp=now_iso(),
                        )
                return SafetyResult(
                    task_id=context.task.task_id,
                    phase="step",
                    scope=f"step:{step.id}",
                    action="allow",
                    risk_flags=[],
                    timestamp=now_iso(),
                )

        agent = ForbiddenMotifSafetyAgent()
        result = agent.check_pre_step(step, dummy_context)

        assert result.action == "block"
        assert len(result.risk_flags) == 1
        assert result.risk_flags[0].code == "FORBIDDEN_MOTIF_PRESENT"
        assert result.risk_flags[0].level == "block"
        assert "MKTA" in result.risk_flags[0].message
        assert result.timestamp is not None

    def test_pre_step_allow_when_no_forbidden_motif(
        self,
        dummy_context: WorkflowContext,
    ):
        """pre_step 放行：序列不含 forbidden motif 时返回 allow"""
        step = PlanStep(
            id="S1",
            tool="protgpt2",
            inputs={"sequence": "NLYIQWLKDGGPSSGRPPPS"},
            metadata={"constraints": {"forbidden_motifs": ["MKTA"]}},
        )

        class ForbiddenMotifSafetyAgent(SafetyAgent):
            def check_pre_step(self, step, context):
                meta = step.metadata if isinstance(step.metadata, dict) else {}
                motifs = meta.get("constraints", {}).get("forbidden_motifs", [])
                inputs = step.inputs if isinstance(step.inputs, dict) else {}
                seq = inputs.get("sequence", "")
                for motif in motifs:
                    if isinstance(motif, str) and isinstance(seq, str) and motif.upper() in seq.upper():
                        return SafetyResult(
                            task_id=context.task.task_id,
                            phase="step",
                            scope=f"step:{step.id}",
                            action="block",
                            risk_flags=[RiskFlag(
                                code="FORBIDDEN_MOTIF_PRESENT",
                                level="block",
                                scope="step",
                                message=f"Forbidden motif '{motif}' detected in sequence",
                            )],
                            timestamp=now_iso(),
                        )
                return SafetyResult(
                    task_id=context.task.task_id,
                    phase="step",
                    scope=f"step:{step.id}",
                    action="allow",
                    risk_flags=[],
                    timestamp=now_iso(),
                )

        agent = ForbiddenMotifSafetyAgent()
        result = agent.check_pre_step(step, dummy_context)

        assert result.action == "allow"
        assert result.risk_flags == []
