import json
from types import SimpleNamespace

from src.agents.planner import ToolSpec
from src.llm.base_llm_provider import ProviderConfig
from src.llm.provider_payload_parser import ProviderPayloadValidationError
from src.models.contracts import PatchRequest, Plan, PlanStep, ProteinDesignTask
import src.llm.openai_compatible_provider as provider_module


def _setup_dummy_openai(monkeypatch, *, response_content=None, stream_parts=None):
    calls = {}

    class DummyCompletions:
        def create(self, **kwargs):
            calls["request_kwargs"] = kwargs
            if kwargs.get("stream"):
                parts = stream_parts or []
                return iter(
                    [
                        SimpleNamespace(
                            choices=[
                                SimpleNamespace(
                                    delta=SimpleNamespace(
                                        content=part,
                                        reasoning_content=None,
                                    )
                                )
                            ]
                        )
                        for part in parts
                    ]
                )
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content=response_content)
                    )
                ]
            )

    class DummyOpenAI:
        def __init__(self, **kwargs):
            calls["client_kwargs"] = kwargs
            self.chat = SimpleNamespace(completions=DummyCompletions())

    monkeypatch.setattr(provider_module, "OPENAI_AVAILABLE", True)
    monkeypatch.setattr(provider_module, "OpenAI", DummyOpenAI, raising=False)
    return calls


def _sample_task():
    return ProteinDesignTask(
        task_id="task_001",
        goal="design a protein",
        constraints={},
        metadata={},
    )


def _sample_registry():
    return [
        ToolSpec(
            id="dummy_tool",
            capabilities=("design",),
            inputs=(),
            outputs=(),
            cost=1,
            safety_level=0,
        )
    ]


def test_openai_provider_uses_config_options(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    calls = _setup_dummy_openai(monkeypatch, response_content=json.dumps(plan_dict))

    config = ProviderConfig(
        model_name="test-model",
        api_key="test-key",
        timeout=12,
        max_tokens=123,
        temperature=0.9,
        top_p=0.5,
        extra_body={"foo": "bar"},
    )
    provider = provider_module.OpenAICompatibleProvider(
        config,
        endpoint="http://example.test/v1",
    )

    plan = provider.call_planner(task, _sample_registry())

    assert plan["task_id"] == task.task_id
    assert calls["client_kwargs"]["api_key"] == "test-key"
    assert calls["client_kwargs"]["base_url"] == "http://example.test/v1"

    request_kwargs = calls["request_kwargs"]
    assert request_kwargs["model"] == "test-model"
    assert request_kwargs["temperature"] == 0.9
    assert request_kwargs["top_p"] == 0.5
    assert request_kwargs["max_tokens"] == 123
    assert request_kwargs["timeout"] == 12
    assert request_kwargs["extra_body"] == {"foo": "bar"}
    assert request_kwargs["response_format"] == {"type": "json_object"}


def test_openai_provider_supports_json_schema_response_format(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    calls = _setup_dummy_openai(monkeypatch, response_content=json.dumps(plan_dict))

    provider = provider_module.OpenAICompatibleProvider(
        ProviderConfig(
            model_name="qwen3.6-flash",
            api_key="test-key",
            max_tokens=None,
            structured_output_mode="json_schema",
        ),
        endpoint="https://dashscope.aliyuncs.com/compatible-mode/v1",
    )

    provider.call_planner(task, _sample_registry())

    request_kwargs = calls["request_kwargs"]
    assert "max_tokens" not in request_kwargs
    assert request_kwargs["response_format"]["type"] == "json_schema"
    assert request_kwargs["response_format"]["json_schema"]["name"] == "plan"


def test_openai_provider_streams_content(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    content = json.dumps(plan_dict)
    calls = _setup_dummy_openai(
        monkeypatch,
        stream_parts=[content[:10], content[10:]],
    )

    config = ProviderConfig(
        model_name="test-model",
        api_key="test-key",
        stream=True,
        use_response_format=False,
    )
    provider = provider_module.OpenAICompatibleProvider(config)

    plan = provider.call_planner(task, _sample_registry())

    assert plan["task_id"] == task.task_id
    request_kwargs = calls["request_kwargs"]
    assert request_kwargs["stream"] is True
    assert "response_format" not in request_kwargs


def test_openai_provider_includes_tool_details_in_prompt(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    calls = _setup_dummy_openai(monkeypatch, response_content=json.dumps(plan_dict))

    config = ProviderConfig(
        model_name="test-model",
        api_key="test-key",
    )
    provider = provider_module.OpenAICompatibleProvider(config)

    provider.call_planner(task, _sample_registry())

    user_prompt = calls["request_kwargs"]["messages"][1]["content"]
    assert "可用工具" in user_prompt
    assert "dummy_tool" in user_prompt
    assert "自然语言要求" in user_prompt
    assert "goal_type" in user_prompt


def test_openai_provider_system_prompt_mentions_natural_language_planning(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    calls = _setup_dummy_openai(monkeypatch, response_content=json.dumps(plan_dict))

    config = ProviderConfig(
        model_name="test-model",
        api_key="test-key",
    )
    provider = provider_module.OpenAICompatibleProvider(config)

    provider.call_planner(task, _sample_registry())

    system_prompt = calls["request_kwargs"]["messages"][0]["content"]
    assert "解析自然语言任务目标" in system_prompt
    assert "生成可执行的结构化 Plan JSON" in system_prompt


def test_openai_provider_stream_ignores_empty_choices(monkeypatch):
    task = _sample_task()
    plan_dict = {
        "task_id": task.task_id,
        "steps": [
            {"id": "S1", "tool": "dummy_tool", "inputs": {}, "metadata": {}}
        ],
        "constraints": {},
        "metadata": {},
    }
    content = json.dumps(plan_dict)
    calls = {}

    class DummyCompletions:
        def create(self, **kwargs):
            calls["request_kwargs"] = kwargs
            return iter(
                [
                    SimpleNamespace(choices=[]),
                    SimpleNamespace(
                        choices=[
                            SimpleNamespace(
                                delta=SimpleNamespace(content=content, reasoning_content=None)
                            )
                        ]
                    ),
                ]
            )

    class DummyOpenAI:
        def __init__(self, **kwargs):
            calls["client_kwargs"] = kwargs
            self.chat = SimpleNamespace(completions=DummyCompletions())

    monkeypatch.setattr(provider_module, "OPENAI_AVAILABLE", True)
    monkeypatch.setattr(provider_module, "OpenAI", DummyOpenAI, raising=False)

    config = ProviderConfig(
        model_name="test-model",
        api_key="test-key",
        stream=True,
        use_response_format=False,
    )
    provider = provider_module.OpenAICompatibleProvider(config)

    plan = provider.call_planner(task, _sample_registry())

    assert plan["task_id"] == task.task_id


def test_openai_provider_uses_plan_patch_schema_for_patch(monkeypatch):
    patch_dict = {
        "task_id": "task_patch",
        "operations": [
            {
                "op": "replace_step",
                "target": "S1",
                "step": {
                    "tool": "dummy_tool",
                    "inputs": {},
                    "metadata": {},
                },
            }
        ],
        "metadata": {"recovery_layer": "tool_level", "reason": "swap"},
    }
    calls = _setup_dummy_openai(monkeypatch, response_content=json.dumps(patch_dict))
    provider = provider_module.OpenAICompatibleProvider(
        ProviderConfig(
            model_name="qwen3.6-flash",
            api_key="test-key",
            structured_output_mode="json_schema",
        )
    )

    patch = provider.call_patch(
        PatchRequest(
            task_id="task_patch",
            original_plan=Plan(
                task_id="task_patch",
                steps=[
                    PlanStep(
                        id="S1", tool="dummy_tool", inputs={}, metadata={}
                    )
                ],
                constraints={},
                metadata={},
            ),
            context_step_results=[],
            safety_events=[],
            reason="retry exhausted",
        ),
        _sample_registry(),
    )

    assert patch is not None
    assert calls["request_kwargs"]["response_format"]["json_schema"]["name"] == "plan_patch"


def test_openai_provider_empty_response_raises_with_diagnostic_summary(monkeypatch):
    task = _sample_task()
    _setup_dummy_openai(monkeypatch, response_content="")

    provider = provider_module.OpenAICompatibleProvider(
        ProviderConfig(
            model_name="test-model",
            api_key="test-key",
            max_tokens=8,
            structured_output_mode="json_schema",
        ),
        endpoint="http://example.test/v1",
    )

    try:
        provider.call_planner(task, _sample_registry())
    except ProviderPayloadValidationError as exc:
        payload = exc.as_event_payload()
    else:
        raise AssertionError("expected ProviderPayloadValidationError")

    assert payload["failure_code"] == "empty_response"
    failure = payload["failures"][0]
    assert failure["code"] == "EMPTY_PROVIDER_RESPONSE"
    observed = failure["observed"]
    assert observed["provider"] == "openai_compatible"
    assert observed["model"] == "test-model"
    assert observed["endpoint"] == "http://example.test/v1"
    assert observed["request"]["max_tokens"] == 8
    assert observed["request"]["response_format_type"] == "json_schema"
    assert observed["request"]["prompt"]["system"]["chars"] > 0
    assert observed["response"]["choices_count"] == 1
    assert "structured_output_mode_may_be_unsupported_or_unsatisfied" in observed["possible_causes"]


def test_openai_provider_invocation_failure_raises_with_diagnostic_summary(
    monkeypatch,
):
    task = _sample_task()
    calls = {}

    class DummyCompletions:
        def create(self, **kwargs):
            calls["request_kwargs"] = kwargs
            raise TimeoutError("Request timed out.")

    class DummyOpenAI:
        def __init__(self, **kwargs):
            calls["client_kwargs"] = kwargs
            self.chat = SimpleNamespace(completions=DummyCompletions())

    monkeypatch.setattr(provider_module, "OPENAI_AVAILABLE", True)
    monkeypatch.setattr(provider_module, "OpenAI", DummyOpenAI, raising=False)

    provider = provider_module.OpenAICompatibleProvider(
        ProviderConfig(
            model_name="test-model",
            api_key="test-key",
            timeout=300,
            max_tokens=393216,
        ),
        endpoint="http://example.test/v1",
    )

    try:
        provider.call_planner(task, _sample_registry())
    except ProviderPayloadValidationError as exc:
        payload = exc.as_event_payload()
    else:
        raise AssertionError("expected ProviderPayloadValidationError")

    assert payload["failure_code"] == "provider_invocation_failed"
    failure = payload["failures"][0]
    assert failure["code"] == "PROVIDER_INVOCATION_FAILED"
    observed = failure["observed"]
    assert observed["provider"] == "openai_compatible"
    assert observed["model"] == "test-model"
    assert observed["request"]["max_tokens"] == 393216
    assert observed["exception"]["type"] == "TimeoutError"
    assert "provider_request_timeout" in observed["possible_causes"]
